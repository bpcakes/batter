import sys
from html.parser import HTMLParser

class Extract(HTMLParser):
    def handle_data(self, data):
        print(data, end=' ')

for path in sys.argv[1:]:
    print('\nDOCUMENT:', path)
    with open(path) as document:
        Extract().feed(document.read())
    print()
