use std::{sync::{Arc, Mutex}, time::Duration};
use batter::{cleanup::{CleanupBudget, CleanupOutcome, CleanupReport}, command::{Command, CommandCause}, lifecycle::{ShutdownBudget, Supervisor}, operation::{OperationContext, OperationError}, startup::{Startup, StartupCause, StartupError, StartupScope}};
use sqlx::{PgPool, postgres::{PgPoolOptions, PgConnectOptions, PgSslMode}};

#[derive(Debug)]
enum AppError {
    Registration(batter::RegistrationError),
    Connect(OperationError<batter_sqlx::SqlxFailure>),
    Query(sqlx::Error),
    Later { stage: &'static str, code: u32 },
}
impl From<batter::RegistrationError> for AppError { fn from(e: batter::RegistrationError) -> Self { Self::Registration(e) } }
impl From<OperationError<batter_sqlx::SqlxFailure>> for AppError { fn from(e: OperationError<batter_sqlx::SqlxFailure>) -> Self { Self::Connect(e) } }
impl From<sqlx::Error> for AppError { fn from(e: sqlx::Error) -> Self { Self::Query(e) } }
type Witnesses = Arc<Mutex<Vec<PgPool>>>;

fn cleanup_budget() -> CleanupBudget {
    CleanupBudget::new(Duration::from_secs(3), Duration::from_secs(3), Duration::from_secs(1)).unwrap()
}
fn context() -> OperationContext { OperationContext::new(Duration::from_secs(10)).unwrap() }
fn options() -> (PgPoolOptions, PgConnectOptions) {
    (PgPoolOptions::new().max_connections(2).acquire_timeout(Duration::from_secs(2)),
     PgConnectOptions::new_without_pgpass().host("/tmp/batter-pool-api.WWWDTk").port(55439)
        .username("pool_test").database("postgres").ssl_mode(PgSslMode::Disable))
}
fn later(stage: &'static str, fail: Option<&'static str>) -> Result<(), AppError> {
    if fail == Some(stage) { Err(AppError::Later { stage, code: 41 }) } else { Ok(()) }
}
async fn query(pool: &PgPool) -> Result<(), AppError> {
    let value: i32 = sqlx::query_scalar("SELECT 1").fetch_one(pool).await?;
    assert_eq!(value, 1);
    Ok(())
}
fn check_cleanup(report: &CleanupReport) {
    assert!(report.is_success());
    assert!(report.skipped.is_empty());
    assert_eq!(report.records.len(), 2);
    assert_eq!(report.records[0].name, "audit_database");
    assert_eq!(report.records[1].name, "database");
    for record in &report.records {
        assert_eq!(record.outcome, CleanupOutcome::Succeeded);
        assert!(record.error.is_none());
    }
    println!("complete cleanup: {report:?}");
}
async fn check_witnesses(witnesses: Witnesses) {
    let pools = witnesses.lock().unwrap().clone();
    assert_eq!(pools.len(), 2);
    for pool in pools {
        assert!(pool.is_closed());
        assert_eq!(pool.size(), 0);
        let result = tokio::time::timeout(Duration::from_secs(1), pool.acquire()).await.unwrap();
        assert!(matches!(result, Err(sqlx::Error::PoolClosed)));
    }
    println!("independent pool clone: size=0; acquire=PoolClosed");
}
async fn finite_setup(native: [(PgPoolOptions, PgConnectOptions); 2], fail: Option<&'static str>) {
    let witnesses = Witnesses::default();
    let observed = witnesses.clone();
    let owner = Command::new(context(), cleanup_budget(), move |scope| Box::pin(async move {
        let work = scope.context().clone();
        let slot = scope.reserve_cleanup("database")?;
        let [primary, secondary] = native;
        let pool = pool_api_experiment::connect_in(slot, primary.0, primary.1, &work).await?;
        observed.lock().unwrap().push(pool.clone());
        query(&pool).await?;
        let slot = scope.reserve_cleanup("audit_database")?;
        let audit_pool = pool_api_experiment::connect_in(slot, secondary.0, secondary.1, &work).await?;
        observed.lock().unwrap().push(audit_pool.clone());
        query(&audit_pool).await?;
        scope.stage("catalog")?;
        later("catalog", fail)?;
        scope.stage("routes")?;
        later("routes", fail)?;
        Ok::<_, AppError>(())
    })).start();
    let report = owner.wait().await.unwrap();
    if let Some(expected_stage) = fail {
        assert!(matches!(&report.work, Err(CommandCause::Failed(AppError::Later { stage, code: 41 })) if *stage == expected_stage));
        assert_eq!(report.stage, expected_stage);
        assert!(!report.is_success());
    } else { assert!(report.is_success()); }
    assert!(report.interruption_after_work.is_none());
    assert!(report.destruction_panic.is_none());
    check_cleanup(report.cleanup.as_ref().unwrap());
    check_witnesses(witnesses).await;
    println!("finite_setup fail={fail:?}: typed work retained and cleanup awaited");
}
async fn initialize_service(scope: &mut StartupScope, work: OperationContext, native: [(PgPoolOptions, PgConnectOptions); 2], fail: Option<&'static str>, observed: Witnesses) -> Result<(), AppError> {
    let slot = scope.supervisor().reserve_cleanup("database")?;
    let [primary, secondary] = native;
    let pool = pool_api_experiment::connect_in(slot, primary.0, primary.1, &work).await?;
    observed.lock().unwrap().push(pool.clone());
    query(&pool).await?;
    let slot = scope.supervisor().reserve_cleanup("audit_database")?;
    let audit_pool = pool_api_experiment::connect_in(slot, secondary.0, secondary.1, &work).await?;
    observed.lock().unwrap().push(audit_pool.clone());
    query(&audit_pool).await?;
    scope.stage("catalog")?;
    later("catalog", fail)?;
    scope.stage("routes")?;
    later("routes", fail)?;
    scope.supervisor().register("worker", move |shutdown| async move {
        shutdown.mark_started();
        shutdown.draining().await;
        drop((pool, audit_pool));
        Ok(())
    })?;
    Ok(())
}
async fn service(fail: Option<&'static str>) {
    let witnesses = Witnesses::default();
    let observed = witnesses.clone();
    let cleanup = cleanup_budget();
    let second = Duration::from_secs(1);
    let supervisor = Supervisor::new(ShutdownBudget::new(second, second, second, cleanup).unwrap());
    let work = context();
    let initializer_context = work.clone();
    let mut starting = Startup::new(supervisor, work, cleanup, move |scope| Box::pin(initialize_service(scope, initializer_context, [options(), options()], fail, observed))).start();
    match starting.wait().await {
        Ok(running) => {
            assert!(fail.is_none());
            running.handle().wait_ready().await.unwrap();
            let report = running.shutdown().await.unwrap();
            assert!(report.is_success());
            assert!(report.all_direct_tasks_joined());
            check_cleanup(&report.cleanup);
        }
        Err(StartupError::Failed(report)) => {
            let expected_stage = fail.expect("expected initialization failure");
            assert!(matches!(&report.cause, StartupCause::Failed(AppError::Later { stage, code: 41 }) if *stage == expected_stage));
            assert_eq!(report.stage, expected_stage);
            assert!(report.destruction_panic.is_none());
            check_cleanup(&report.cleanup);
        }
        Err(StartupError::Coordinator(_)) => panic!("startup coordinator failed"),
    }
    check_witnesses(witnesses).await;
    println!("service fail={fail:?}: typed work retained and cleanup awaited");
}
#[tokio::main]
async fn main() {
    for fail in [None, Some("catalog"), Some("routes")] { finite_setup([options(), options()], fail).await; service(fail).await; }
}
