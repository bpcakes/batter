fn misuse(scope: &mut batter::startup::ProtectedStartupScope) {
    let _ = scope.registration().start();
}
fn main() {}
