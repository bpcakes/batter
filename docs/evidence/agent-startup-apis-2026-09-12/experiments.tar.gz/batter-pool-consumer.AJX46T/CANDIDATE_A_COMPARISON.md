# Bounded same-agent comparison

This follows the fresh candidate C trial with the same agent. It is not another independent fresh sample. All C artifacts are preserved unchanged. Candidate A copies the initial one-pool command/startup scenario and changes construction to pool_in, retaining SELECT 1 before fallible dependent initialization.

The first source before compilation is candidate_a/src/main.candidate-a-first.rs. The copied main.first.rs and run-1.log are the earlier C artifacts, not A trial evidence.

Exact command (bash with pipefail):

```bash
RUSTUP_TOOLCHAIN=1.98.1 CARGO_TARGET_DIR=/home/aa/Documents/batter/target TMPDIR=/home/aa/.cache cargo run --manifest-path /home/aa/.cache/batter-pool-consumer.AJX46T/candidate_a/Cargo.toml 2>&1 | tee /home/aa/.cache/batter-pool-consumer.AJX46T/candidate_a/run-candidate-a-1.log
```

Result: first compile and all four command/startup positive/later-failure cases pass. No compiler errors, behavioral failures, repairs, or retries. Two dead-code warnings concern retained native query/registration error payloads. Every complete cleanup report contains the expected successful database hook, no errors and no skipped hooks. Independent native clones have size zero and acquisition returns PoolClosed.

## Responsibilities and operation boundaries

Both candidates reserve the named slot and leave close coordination, awaited cleanup, and retained reports to the same owner. A adds no lifecycle cleanup obligation in this scenario. Its returned pool is unauthenticated, so the caller must establish successful first use before dependent work. Here SELECT 1 was already required and serves that purpose directly. No additional probe call, manual close, or recovery helper is needed.

C explicitly acquires/returns a connection before the required query. A constructs lazily and goes straight to SELECT 1. Each variant executes one application query. C's documented acquisition plus SQLx query pool acquisition constitute two acquisition boundaries; A's query has one. This count follows the public contract and consumer call structure, not instrumented acquire callback counts or a claim about physical TCP/Unix connections. SQLx can reuse the returned connection.

A eliminates the cloned CommandScope context used to avoid borrowing against its live mutable cleanup reservation. In startup, A eliminates the extra initializer context argument and cloning the context supplied to Startup. The native query remains inside the owner's already bounded callback, with native acquisition timeout still configured. There is no change to the total work or cleanup budget. C's explicit context is useful when acquisition needs a distinct child allowance, but that capability was not required here.

A also lets the test retain an independent pool clone before authentication finishes; C's failed pre-return authentication only leaves owner-report evidence available. No new acquisition-failure case was run in this bounded comparison.

## Revised preference

For this exact request, I now prefer A plus explicit SELECT 1. The earlier argument favoring C overestimated extra caller choreography: the request already demanded a query before dependent initialization, so it already supplies the authentication boundary. A needs fewer context/borrow/error-conversion choices without giving the caller additional cleanup duties. This is a revision based on implementing A, not evidence that C is incorrect or that all consumers should prefer A.

C still provides a useful authenticated-return contract when dependent work does not otherwise query/probe the database first, or when a distinct bounded acquisition operation is desired. Neither trial establishes password verification (cluster uses local trust), remote session disappearance, cancellation races, or runtime-death behavior. The executed two-pool modification remains C-only; A's corresponding modification was not executed.
