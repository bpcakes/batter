use batter::lifecycle::Supervisor;
struct Wrapper(Supervisor);
impl std::ops::Deref for Wrapper { type Target = Supervisor; fn deref(&self) -> &Supervisor { &self.0 } }
impl std::ops::DerefMut for Wrapper { fn deref_mut(&mut self) -> &mut Supervisor { &mut self.0 } }
fn compatibility(wrapper: &mut Wrapper, listener: tokio::net::TcpListener, app: axum::Router) {
    registration_probe::generic_http(wrapper, "http", listener, app).unwrap();
}
fn main() {}
