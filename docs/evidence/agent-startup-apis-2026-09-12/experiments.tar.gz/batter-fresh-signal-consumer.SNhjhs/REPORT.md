# Fresh signal consumer experiment

Executed on Linux with rustc 1.98.1 (48a229cea 2026-09-01), Tokio pinned to
1.53.1. This is a scratch consumer experiment, not a production change or a
comprehensive verification of the candidate.

Only the candidate PUBLIC_API.md and production public README/docs/generated
rustdoc were consulted. No candidate implementation, tests, prior experiment
reports, ExecPlan or Beads were read. One attempted public rustdoc path,
`startup/enum.StartupObservation.html`, did not exist; that discovery command
reported FileNotFoundError. It did not affect source or execution.

## Choice and implementation

Chose `SignalStartup::new(...).with_unix_signals("signals").start()` because the
inert specification and execution boundary are explicit at the composition
root. Nothing in this experiment establishes that it outperforms the equivalent
helper. The consumer owns `StartingSupervisor`, times out only its borrowed
`wait()` future, releases a oneshot startup gate, then resumes waiting on the
same owner. An ordinary run subsequently reaches Ready, proving the waiter
timeout did not stop initialization.

The initializer reserves a cleanup slot, binds a native UDP socket, and registers
its finalizer before the next await. `acquired` is flushed after registration.
The finalizer awaits 100 ms, drops the socket, records completion, then flushes
`cleanup`. A critical worker acknowledges startup after its own 20 ms
initialization and waits for drain. `ready` is emitted only after `wait_ready`
succeeds and an immediate readiness snapshot is Ready. This is a snapshot, not
a promise that readiness cannot change immediately afterward.

Startup failure retains and inspects `StartupError::Failed` and its cleanup
report. Running completion uses awaited `running.wait()` and `check_shutdown`,
whose unsuccessful result retains the report. Only fixed markers are printed;
error Debug/Display contents are not printed. The application main converts the
experiment's expected, fully checked outcome to exit 0, including expected
startup interruption or injected startup failure. Exit 0 here is a harness
convention, not a recommendation for a production service's startup failure exit
policy.

## Preserved attempts and results

`initial-before-first-compile/` and `modified-before-first-compile/` preserve each
version before its first compiler invocation. Their source matches the final
`initial/` and `modified/` source byte for byte. Cargo generated the lock files.
Both compiled on their first attempt; there were no compiler errors, behavior
failures, or source repairs. Initial compilation emitted two dead-field warnings
for concrete retained error payloads; modified compilation emitted one. Warnings
remain recorded rather than erasing those payloads to silence the compiler.

`initial-build-1.log` and `modified-build-1.log` contain compiler output.
`initial-signals-1.log` contains six passing child runs. For each of SIGTERM and
SIGINT the parent sent a real native signal after `acquired` while startup was
held, after `waiter-timeout` while startup was held, and after `ready` in ordinary
mode. Startup cases retained Draining with successful cleanup; running cases
passed `check_shutdown`. Cleanup preceded the outcome marker and process exit.
Ordinary runs emitted `waiter-timeout` before `ready`.

The modification adds a second fallible socket acquisition, cleanup slot and
validation stage. `--hold-second` waits after registration of the second resource.
`--fail-second` returns a concrete I/O error from validation. The report checks
the retained error kind and its private sentinel without printing the sentinel.
No signal routing call or waiter ownership logic changed.

`modified-signals-1.log` contains nine passing child runs: the original six,
SIGTERM/SIGINT during the second initialization stage, and injected validation
failure. When both resources had been registered, `cleanup-second` preceded
`cleanup`, and both preceded the outcome. The original-stage interruption still
finalized only the first registered resource. No child wrote stderr.

`signals.py` owns subprocess deadlines and signal delivery, checks acknowledged
markers, finalizer count and ordering, exit status, stderr, and the delay between
signal and completion. It kills and reaps its child only if a scenario cannot
finish. Each version's binary is also preserved as `initial/consumer` and
`modified/consumer`.

## Reproduction

```bash
cd /home/aa/.cache/batter-fresh-signal-consumer.SNhjhs
export RUSTUP_TOOLCHAIN=1.98.1
export CARGO_TARGET_DIR=/home/aa/Documents/batter/target
export TMPDIR=/home/aa/.cache
set -o pipefail
cargo build --locked --manifest-path initial/Cargo.toml
python3 signals.py /home/aa/Documents/batter/target/debug/fresh-signal-consumer-initial
cargo build --locked --manifest-path modified/Cargo.toml
python3 signals.py /home/aa/Documents/batter/target/debug/fresh-signal-consumer-modified modified
```

The recorded first build used the same environment with no `--locked`, so Cargo
could create/update scratch lock files. These commands require the candidate and
production dependency paths to remain present. To rerun the preserved binaries
without rebuilding, use `python3 signals.py initial/consumer` and
`python3 signals.py modified/consumer modified` from this directory.

## Limits and consumer obligations

The experiment covers acknowledged resource registration through Ready and
awaited completion, not every possible signal race. In particular it does not
test or claim coverage before `.start()`, before listener installation, between
handoff and readiness, repeated/coalesced signals, registration installation
failure, owner drop, cleanup failure, coordinator failure, process/runtime death,
non-yielding work, or detached descendants. macOS was not executed. The public
contract's process-global signal disposition remains relevant.

The known prototype name-reservation gap was respected by keeping `signals`
distinct; this experiment does not validate name reservation. Consumers still
must reserve cleanup before acquisition, register immediately after ownership
is yielded, acknowledge actual component initialization, inspect retained
completion, and keep a live runtime through cleanup. This experiment gives
positive evidence that adding a startup stage did not require new signal
coordination; it does not prove those other application obligations disappear.
