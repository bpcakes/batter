fn misuse(scope: &mut batter::startup::ProtectedStartupScope) {
    let slot = scope.registration().reserve_cleanup("pool").unwrap();
    slot.register(|| async { Ok(()) });
}
fn main() {}
