# Unix startup signal API experiment

Executed 2026-09-12 on Linux x86_64, Rust 1.98.1, Tokio 1.53.1.
This isolated package depends on the current Batter checkout through its public
API. Production source and tracker were not modified. This is design evidence,
not a delivered feature or a blind fresh-agent usability benchmark.

## Results

`final-run.log` records 14 subprocess scenarios and the exact assertions live in
`src/main.rs`. Each child runs a current-thread Tokio runtime. The external parent
uses native `kill -TERM` / `kill -INT` against that direct child's PID after a
stdout synchronization event, retains output, and imposes an eight-second
wall-clock deadline with kill/reap on expiry. Test processes never signal the
test runner or unrelated processes. Failed ordinary children cannot pass just
by emitting a partial success marker.

1. TERM during pending initialization: initializer destroyed, prior finalizer
   completes once, retained StartupCause::Draining with successful cleanup.
2. INT during pending initialization: same contract.
3. Separate helper shape during pending initialization: same contract.
4. TERM while initialized sources are deliberately unpolled between successful
   initialization and component transfer: pending event survives, driver drains,
   registered cleanup completes. This can legitimately yield an already-draining
   RunningSupervisor rather than a StartupFailure; no lost-event claim is made.
5. TERM after running ownership is received: successful joined shutdown/cleanup.
6. Native invalid signal installation failure: initializer never invoked, prior
   cleanup retained and awaited, native io::Error remains in signal error.
   This uses a fixture-only invalid-signal installer, not an induced failure of
   actual SIGTERM/SIGINT installation. Partial paired-install failure is untested.
7. Pre-existing duplicate component name: initializer never invoked, cleanup runs.
8. Initializer claims the signal component name: current install helper accepts
   installation, application initialization runs, then registration fails late.
   This is a confirmed design gap, explicitly asserted as a negative behavior;
   the prototype has NOT repaired component-name reservation.
9. Startup owner loss during initialization: observer sees retained cleanup.
10. Borrowed waiter timeout: no cleanup until subsequent TERM; cancellation of
    the waiter does not cancel its retained owner.
11. Queued successful handoff owner loss: wait only through observer, then drop
    StartingSupervisor without receiving the queued RunningSupervisor; driver
    and cleanup complete independently.
12. Running owner loss after handoff: observer retains successful shutdown.
13. **Negative control: signal after start returns, before coordinator first
    poll.** Child deliberately blocks its current runtime thread after printing
    `launch-returned`. The asynchronous-install prototype dies by SIGTERM, Unix
    status signal 15. Its previously registered cleanup does not run. This is
    intentional evidence against merely moving application select into a wrapper.
14. **Positive control for synchronous installation:** identical pre-first-poll
    interval, but installed sources exist before start returns. TERM is retained;
    parent releases the scheduling gate and owned startup drives cleanup once.
    The log includes `initializer-entered`: OS arrival is NOT an atomic admission
    fence. Only observed drain precludes further initialization/readiness.

`first-run.log`: initial build could not write to the full /tmp filesystem.
Only this task's own scratch tree was moved to /home/aa/.cache; no unrelated
files were deleted. `second-run.log`: separately binding a closure borrowing
StartupScope with an inferred return lifetime failed to satisfy the higher-rank
factory bound. The fixture introduced a bound-carrying identity helper; inline
constructor closures avoid that inference issue. `third-run.log` was the first
successful 11-case run. The final suite corrected a mislabeled queued-handoff
case to actually drop the owner before consuming the handoff and added controls.

## Candidate surfaces

Candidate A, preferred production shape, is an opt-in policy on the protected
startup builder selected by the registration-capability work:

```rust,ignore
let mut starting = ProtectedStartup::new(supervisor, context, cleanup, |scope| {
    Box::pin(async move {
        // Native application initialization and protected registrations only.
        Ok::<_, AppError>(())
    })
})
.with_unix_signals("signals")
.without_readiness_approval() // Only when the application needs staged approval.
.start();
let running = starting.wait().await?;
check_shutdown(running.wait().await)?;
```

The spelling `ProtectedStartup` is illustrative; coordinate the actual entrypoint
with the constrained-registration delivery. Preserve the existing Startup
contract as the explicit low-level compatibility path. Construction and policy
selection are inert. Explicit start synchronously validates/reserves the signal
name and installs the pair before returning; no application factory runs there.
An installation outcome, including failure, travels into the already owned
startup coordinator and its cleanup report. Do not return an immediate error
that abandons a supervisor with prior registered finalizers.

`SignalStartup` in `src/lib.rs` is a runnable public-only stand-in, not a
production implementation. Its default experiment engine uses asynchronous
installation to reproduce the reference-root protocol; the fixture-only
SynchronousInstall injection establishes the proposed early-install repair.
It has no component reservation capability because the current public API does
not expose one. It also lacks readiness policy passthrough; production must
preserve existing explicit approval semantics.

Candidate B, implemented using the same engine, is a separate root helper:

```rust,ignore
let mut starting = start_with_unix_signals(
    supervisor, context, cleanup, "signals", |scope| Box::pin(async move {
        Ok::<_, AppError>(())
    }),
);
```

Both shapes remove caller-written signal select, drain request and transfer.
Candidate A keeps one discoverable startup owner and composes with readiness
policy without mirroring every startup parameter and method in a second helper.
Candidate B is feasible but increases choices for agent consumers and its
current public-only implementation cannot guarantee name reservation. The
experiment supports ownership mechanics; it does not statistically establish
that agents prefer a method over a function.

Error compatibility: use a new protected initialization error envelope, e.g.
`InitializationError<E> { Application(E), Signals(SignalRegistrationError) }`,
inside the existing StartingSupervisor/StartupFailure structure. This preserves
concrete E, native io::Error and cleanup independently, while avoiding a new
variant on the existing exhaustively-matchable StartupCause enum. Signal drain
remains StartupCause::Draining. Public diagnostics must be fixed/redacted;
the prototype's derived Debug is NOT a production recommendation. Production
Error::source should preserve trusted inspection of E and signal io::Error.

## Delivery acceptance recommendations

- Inert builder: no signal installation, initializer call, task spawn, or cleanup
  invocation before explicit start.
- Explicit start installs both native signal sources before returning on the
  valid current runtime. State preflight and component-name validation precede
  installation. Cover invalid name, existing duplicate, and a component trying
  to claim the reserved name inside initialization.
- Registration after successful installation is infallible by construction;
  do not document a new application ordering convention to avoid collisions.
- Signal installation failure retains prior registered cleanup and original
  native error, and does not invoke application initialization. Catch and retain
  initializer capture-destruction panic independently, using existing behavior.
- No signal gap during successful handoff, queued-owner loss or running-owner
  loss. No detached signal watcher outside an owned report path.
- Cancellation of a borrowed waiter is inert to ownership. Owner drop requests
  drain and independently retained cleanup continues while runtime lives.
- Observed signal causes normal drain; it does not force cancellation early,
  resurrect readiness, discard a concurrently returned application failure, or
  reset shutdown clocks. Define simultaneous-ready precedence explicitly.
- Source pair installation is process-global and can partially succeed; do not
  promise dropping listeners restores OS disposition. Explicit opt-in needed.
- Preserve Unix-only scope and native E identity. Do not add app protocols or
  global signal broker/DI abstractions. Repeat signals are not an exact counter
  because native Tokio streams coalesce; no unasked second-signal force-kill API.
- Do not let an internal signal component falsely satisfy EmptySupervisor's
  requirement for actual application work; assess whether the existing signal
  component semantics should remain or whether hidden sources belong directly
  in the coordinator. This policy choice was not tested here.
- Migrate PostgreSQL and reference roots to the protected path, removing all
  manual signal selection/transfers. Keep manual APIs explicitly lower-level.
- Add canonical rustdoc/example, contracts, implemented-status and source/version
  references. Required two-toolchain/Jig/HTTP checks are production acceptance,
  not claimed executed by this isolated spike.

Unexecuted: macOS, Rust 1.94, partial native TERM/INT install failure, process-wide
multiple startup-owner interaction, exact co-ready error/panic/destructor
precedence, a component reservation repair, final constrained scope integration,
no-component readiness semantics, no-runtime/disabled signal driver installation,
and a blind agent implementation task against final candidate docs.

## Source evidence and upstream semantics

- `examples/reference-service/src/runtime.rs:126` manually installs, selects,
  requests readiness drain and later registers the listener component.
- `examples/postgres-lifecycle/src/main.rs:74` initializes/probes before signals.
- `crates/batter/src/lifecycle/unix.rs:88` receiver is cancellation-safe and
  remembers completed reception; line 107 transfers the native sources.
- `crates/batter/src/lifecycle/unix.rs:149` check_component_name only validates;
  no reservation exists. Supervisor::register at lifecycle.rs:356 mutates later.
- `crates/batter/src/startup/driver.rs:102` start launches asynchronous ownership;
  `drive` owns cleanup and handoff, and `initialize_owned` catches callbacks and
  destruction under context/drain checks.
- Primary versioned Tokio documentation checked 2026-09-12:
  https://docs.rs/tokio/1.53.1/tokio/signal/unix/struct.Signal.html
  It specifies process-wide persistent handler changes, native notification
  coalescing, cancel-safe recv and that recv never returns None in this version.
- Local pinned Tokio source `src/signal/unix.rs:268` checks invalid/forbidden
  signal numbers before installation and returns native io::Error, used by the
  fixture installation-failure branch.

## Public-only consumer instructions for a future independent exercise

Using only the candidate rustdoc and adapter docs, initialize one resource with
explicit owned cleanup, register a channel worker, and select native SIGTERM and
SIGINT shutdown support. Initialization may pause after acquisition. Ensure
signal delivery during that pause causes retained cleanup, cancelled borrowed
wait does not cancel startup, and successful handoff remains signal responsive.
Do not consult implementation internals or write a signal-select/transfer loop.
Produce one application root and then modify it to withhold application readiness
until an explicit external approval while preserving signal responsiveness.
The evaluator should supply external process tests, including the pre-first-poll
negative-control scenario, without revealing the implementation mechanics.

## Reproduction

```sh
TMPDIR=/home/aa/.cache/batter-signal-api.t2SEh7 cargo run --manifest-path /home/aa/.cache/batter-signal-api.t2SEh7/experiment/Cargo.toml --offline --locked
```

To relocate the artifact, adjust its Cargo.toml Batter path to the evaluated
checkout. Cargo.lock is Cargo-generated. No workspace test receipts are claimed.
