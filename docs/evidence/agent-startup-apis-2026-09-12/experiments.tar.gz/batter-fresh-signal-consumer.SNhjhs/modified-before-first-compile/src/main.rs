use batter::{
    cleanup::CleanupBudget,
    lifecycle::{Readiness, ShutdownBudget, Supervisor, check_shutdown},
    operation::OperationContext,
    startup::{StartupCause, StartupError},
};
use signal_public_candidate::{InitializeError, SignalStartup};
use std::{io::Write, process::ExitCode, sync::{Arc, atomic::{AtomicUsize, Ordering}}, time::Duration};

enum AppError {
    Registration(batter::RegistrationError),
    Io(std::io::Error),
}
impl From<batter::RegistrationError> for AppError {
    fn from(error: batter::RegistrationError) -> Self { Self::Registration(error) }
}
impl From<std::io::Error> for AppError {
    fn from(error: std::io::Error) -> Self { Self::Io(error) }
}

fn marker(value: &'static str) {
    let mut output = std::io::stdout().lock();
    let _ = writeln!(output, "{value}");
    let _ = output.flush();
}

#[tokio::main]
async fn main() -> ExitCode {
    match run().await {
        Ok(true) => ExitCode::SUCCESS,
        Ok(false) => ExitCode::FAILURE,
        Err(_) => { marker("outcome:configuration-failed"); ExitCode::FAILURE }
    }
}

async fn run() -> Result<bool, batter::ConfigurationError> {
    let hold = std::env::args().any(|arg| arg == "--hold-startup");
    let hold_second = std::env::args().any(|arg| arg == "--hold-second");
    let fail_second = std::env::args().any(|arg| arg == "--fail-second");
    let second = Duration::from_secs(1);
    let cleanup = CleanupBudget::new(second, second, second)?;
    let supervisor = Supervisor::new(ShutdownBudget::new(second, second, second, cleanup)?);
    let context = OperationContext::new(Duration::from_secs(30))?;
    let completed = Arc::new(AtomicUsize::new(0));
    let cleaned = completed.clone();
    let registered = Arc::new(AtomicUsize::new(0));
    let registered_in_startup = registered.clone();
    let cleaned_second = completed.clone();
    let (resume, held) = tokio::sync::oneshot::channel();
    let mut starting = SignalStartup::new(supervisor, context, cleanup, move |scope| Box::pin(async move {
        scope.stage("resource.acquire")?;
        let slot = scope.supervisor().reserve_cleanup("resource")?;
        let socket = tokio::net::UdpSocket::bind("127.0.0.1:0").await?;
        slot.register(move || async move {
            tokio::time::sleep(Duration::from_millis(100)).await;
            drop(socket);
            cleaned.fetch_add(1, Ordering::SeqCst);
            marker("cleanup");
            Ok(())
        });
        registered_in_startup.fetch_add(1, Ordering::SeqCst);
        marker("acquired");
        scope.stage("resource.initialize")?;
        let _ = held.await;
        if hold { std::future::pending::<()>().await; }
        scope.stage("secondary.acquire")?;
        let slot = scope.supervisor().reserve_cleanup("secondary")?;
        let socket = tokio::net::UdpSocket::bind("127.0.0.1:0").await?;
        slot.register(move || async move {
            tokio::time::sleep(Duration::from_millis(100)).await;
            drop(socket);
            cleaned_second.fetch_add(1, Ordering::SeqCst);
            marker("cleanup-second");
            Ok(())
        });
        registered_in_startup.fetch_add(1, Ordering::SeqCst);
        marker("acquired-second");
        scope.stage("secondary.validate")?;
        if hold_second { std::future::pending::<()>().await; }
        tokio::time::sleep(Duration::from_millis(20)).await;
        if fail_second {
            return Err(AppError::Io(std::io::Error::new(
                std::io::ErrorKind::PermissionDenied, "private-stage-error-sentinel"
            )));
        }
        scope.supervisor().register("worker", |shutdown| async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            shutdown.mark_started();
            shutdown.draining().await;
            Ok(())
        })?;
        Ok::<(), AppError>(())
    })).with_unix_signals("signals").start();

    let outcome = match tokio::time::timeout(Duration::from_millis(50), starting.wait()).await {
        Ok(outcome) => outcome,
        Err(_) => {
            marker("waiter-timeout");
            let _ = resume.send(());
            starting.wait().await
        }
    };
    match outcome {
        Ok(running) => {
            let handle = running.handle();
            if handle.wait_ready().await.is_ok() && handle.readiness() == Readiness::Ready {
                marker("ready");
            }
            let shutdown_outcome = running.wait().await;
            let verified = check_shutdown(shutdown_outcome);
            let success = verified.is_ok() && completed.load(Ordering::SeqCst) == 2;
            marker(if success { "outcome:shutdown-ok" } else { "outcome:shutdown-failed" });
            Ok(success)
        }
        Err(StartupError::Failed(report)) => {
            let drained = matches!(report.cause, StartupCause::Draining);
            let application_failed = matches!(&report.cause,
                StartupCause::Failed(InitializeError::Application(AppError::Io(error)))
                if error.kind() == std::io::ErrorKind::PermissionDenied
                    && error.to_string() == "private-stage-error-sentinel");
            let success = (drained || application_failed)
                && report.destruction_panic.is_none()
                && report.cleanup.is_success()
                && report.cleanup.records.len() == registered.load(Ordering::SeqCst)
                && completed.load(Ordering::SeqCst) == registered.load(Ordering::SeqCst);
            marker(if success && drained { "outcome:startup-draining-clean" }
                else if success { "outcome:startup-application-clean" }
                else { "outcome:startup-failed" });
            Ok(success)
        }
        Err(StartupError::Coordinator(_)) => {
            marker("outcome:coordinator-failed");
            Ok(false)
        }
    }
}
