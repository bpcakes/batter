use batter::{cleanup::CleanupBudget, lifecycle::Supervisor, operation::OperationContext,
    startup::{StartupScope, StartupFuture, StartingSupervisor}};
pub use signal_api_experiment::InitializeError;

/// Scratch public projection of the tested synchronous installation candidate.
pub struct SignalStartup<F>(signal_api_experiment::SignalStartup<F>);
impl<F> SignalStartup<F> {
    pub fn new<E>(supervisor: Supervisor, context: OperationContext, cleanup: CleanupBudget, initialize: F) -> Self
    where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> {
        Self(signal_api_experiment::SignalStartup::new(supervisor, context, cleanup, initialize)
            .inject(signal_api_experiment::Injection::SynchronousInstall))
    }
    pub fn with_unix_signals(self, name: &'static str) -> Self {
        Self(self.0.with_unix_signals(name))
    }
    pub fn start<E>(self) -> StartingSupervisor<InitializeError<E>>
    where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> + Send + 'static,
        E: Send + Sync + 'static {
        self.0.start()
    }
}
pub fn start_with_unix_signals<F, E>(supervisor: Supervisor, context: OperationContext,
    cleanup: CleanupBudget, name: &'static str, initialize: F) -> StartingSupervisor<InitializeError<E>>
where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> + Send + 'static,
    E: Send + Sync + 'static {
    SignalStartup::new(supervisor, context, cleanup, initialize).with_unix_signals(name).start()
}
