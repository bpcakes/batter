fn misuse(scope: &mut batter::startup::ProtectedStartupScope) {
    let _ = scope.registration().take_cleanup();
}
fn main() {}
