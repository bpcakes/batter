struct Application;
impl batter::registration::RegistrationTarget for Application {
    fn registration(&mut self) -> batter::registration::Registration<'_> { unimplemented!() }
}
fn main() {}
