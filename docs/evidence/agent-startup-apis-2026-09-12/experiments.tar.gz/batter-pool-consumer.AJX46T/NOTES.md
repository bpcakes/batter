# Fresh consumer trial

Selected candidate C because the task requires authentication before dependent initialization. A successful connect_in establishes acquisition and registration together; SELECT 1 is still explicit. Candidate A would require a separate authentication boundary and more caller choreography.

Read PUBLIC_API.md and existing Batter public README, guarantees and command/startup rustdoc. Generated rustdoc supplied report fields. No prototype implementation/tests, prior reports, planning or tracker files were inspected.

Initial source is preserved as initial/src/main.first.rs before first compile. Separate modification artifact follows initial execution.

Commands use Rust 1.98.1, shared target directory and cache TMPDIR. Full compile/run logs are preserved alongside each artifact.

Public API ambiguities: StartupScope has no context accessor, so initialization receives a clone of the context passed to Startup. Its reservation lives through supervisor(), unlike CommandScope. The API comparison omits the actual import/module path, so crate-root connect_in is inferred. Native pool clones are sufficient inspection handles after return, but connect_in failure before return exposes no clone, so those cases would rely on owner cleanup evidence alone.

Non-code discovery errors: docs/usage does not exist; generated rustdoc StartupFailure/StartupError kind was initially guessed backwards, then corrected via the other rustdoc links. These did not change implementation.

Initial run: first compile and all four behaviors passed. Three dead-code warnings concern retained concrete Registration/Connect/Query payloads, which are not exercised by these later-application-failure scenarios. No compiler or behavioral failures; no repairs or retries. The test database uses local trust, so successful authentication is an actual accepted PostgreSQL connection, not evidence of password verification.

Initial exact command (bash with pipefail):
RUSTUP_TOOLCHAIN=1.98.1 CARGO_TARGET_DIR=/home/aa/Documents/batter/target TMPDIR=/home/aa/.cache cargo run --manifest-path /home/aa/.cache/batter-pool-consumer.AJX46T/initial/Cargo.toml 2>&1 | tee /home/aa/.cache/batter-pool-consumer.AJX46T/initial/run-1.log

Modification adds audit_database from independently supplied native options and a routes failure after catalog. Both command and startup check success, catalog error, and routes error. Cleanup assertions require exact LIFO names, two successful hook records, no errors, and no skipped hooks; independent clones must have size 0 and acquire return PoolClosed. No manual pool close helper exists. Modification's copied run-1.log/main.first.rs remain initial historical artifacts; run-modification-1.log and main.modification-first.rs belong to the modification.

Modification exact command (bash with pipefail):
RUSTUP_TOOLCHAIN=1.98.1 CARGO_TARGET_DIR=/home/aa/Documents/batter/target TMPDIR=/home/aa/.cache cargo run --manifest-path /home/aa/.cache/batter-pool-consumer.AJX46T/modification/Cargo.toml 2>&1 | tee /home/aa/.cache/batter-pool-consumer.AJX46T/modification/run-modification-1.log

Modification result: first compile and all six behaviors passed. Same three retained-payload warnings, no compiler or behavioral failures, no repairs, no retries. Both initial and modified complete success cases and typed later errors execute SELECT 1 before reaching application stages. Initial and modified Cargo.lock files are Cargo-generated.

Context choice: candidate C's explicit context argument made me clone CommandScope::context before reserving its mutable cleanup slot; doing the clone afterward would risk overlapping mutable/immutable scope borrowing. This was anticipated before compiling, so no compiler repair was needed. StartupScope's public API has no context accessor. I passed a clone of the exact context supplied to Startup into initialize_service; both therefore share the same absolute startup deadline, with no restarted budget. Owner supervision still bounds native SELECT 1 even though query() does not accept a separate context. I chose a 10-second work allowance, native 2-second acquisition timeout, and independent cleanup allowance. With two pools I reused that same context for both connect_in calls. There was no budget inflation. These are caller decisions that the comparison could illustrate more explicitly, especially the differing Command/Startup access paths.

Assessment remains candidate C for this authentication-before-dependent-work task. The native explicit SELECT 1 remains necessary, but I prefer an authenticated-return contract over a lazy-return contract. This bounded trial does not establish candidate A is deficient in other tasks, nor does it evaluate candidate C's cancellation-before-return cases, retained checked-out connections, remote server session disappearance, password authentication, or runtime death. No database or role provisioning was performed.
