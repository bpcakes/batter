# Experimental startup signals

This package is signal-public-candidate at this directory. Use the production
batter crate at /home/aa/Documents/batter/crates/batter and Rust 1.98.1.
Two equivalent candidate public surfaces are available:

SignalStartup::new(supervisor, context, cleanup_budget, initializer)
    .with_unix_signals("signals").start()

start_with_unix_signals(supervisor, context, cleanup_budget, "signals", initializer)

The initializer uses the existing native StartupFuture and StartupScope callback
shape. It performs native acquisition and component/finalizer registration;
the helper installs native SIGTERM/SIGINT listeners synchronously at start,
observes them during initialization and carries reception into running supervision.
No manual signal select, listener transfer or relay task belongs in the consumer.
Before start, the specification is inert. Signal handling begins at start and
is process-global; dropping Tokio listeners does not restore default dispositions.

The returned owner is StartingSupervisor<InitializeError<E>>. Borrow its wait()
to obtain RunningSupervisor; dropping a borrowed waiter does not cancel startup.
Dropping the owner requests drain while owned cleanup continues on the live runtime.
Application failures remain E under InitializeError::Application(E); signal
installation failures are InitializeError::Signals(SignalRegistrationError).
Signal reception during startup produces the existing StartupCause::Draining.
Inspect the retained cleanup report along with the startup cause. Choose fixed
application output; do not print these prototype errors with Debug.

Native components still acknowledge real initialization. Startup supplies
application approval after initializer success. Await running shutdown/report
using the existing public helpers. Runtime death, non-yielding callbacks and
arbitrary detached descendants retain existing limitations.

This scratch candidate currently validates the selected name but does not reserve
it before the application initializer. Do not register another component with the
selected name. The production proposal must remove this remaining obligation;
this experiment does not claim name-reservation protection.
