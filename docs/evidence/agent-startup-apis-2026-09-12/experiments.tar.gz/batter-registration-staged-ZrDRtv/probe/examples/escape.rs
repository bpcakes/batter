fn misuse(scope: &mut batter::startup::ProtectedStartupScope) {
    let mut target = scope.registration();
    tokio::spawn(async move {
        target.register("worker", |stop| async move { stop.draining().await; Ok(()) }).unwrap();
    });
}
fn main() {}
