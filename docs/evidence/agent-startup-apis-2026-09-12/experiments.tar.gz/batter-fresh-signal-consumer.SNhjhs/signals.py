import json
import os
import selectors
import signal
import subprocess
import sys
import time

binary = sys.argv[1]
modified = len(sys.argv) > 2 and sys.argv[2] == "modified"

def scenario(name, arguments, acknowledged, sig, expected, second=False):
    child = subprocess.Popen([binary, *arguments], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    started = time.monotonic()
    received = []
    buffered = b""
    sent = None
    selector = selectors.DefaultSelector()
    selector.register(child.stdout, selectors.EVENT_READ)
    try:
        while time.monotonic() - started < 10:
            for key, _ in selector.select(0.05):
                chunk = os.read(key.fd, 4096)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                buffered += chunk
                while b"\n" in buffered:
                    raw, buffered = buffered.split(b"\n", 1)
                    line = raw.decode()
                    received.append(line)
                    if line == acknowledged and sent is None:
                        os.kill(child.pid, sig)
                        sent = time.monotonic()
            if child.poll() is not None and not selector.get_map():
                break
        else:
            raise AssertionError("child timeout")
        code = child.wait(timeout=1)
        stderr = child.stderr.read().decode()
        assert code == 0, (code, received, stderr)
        assert not stderr, stderr
        assert received.count("cleanup") == 1, received
        assert received[-1] == expected, received
        assert received.index("acquired") < received.index("cleanup"), received
        assert received.index("cleanup") < len(received) - 1, received
        if second:
            assert received.count("cleanup-second") == 1, received
            assert received.index("cleanup-second") < received.index("cleanup"), received
        else:
            assert "cleanup-second" not in received, received
        if acknowledged == "ready":
            assert received.index("waiter-timeout") < received.index("ready"), received
        if "--hold-startup" in arguments or "--fail-second" in arguments:
            assert "ready" not in received, received
        assert acknowledged is None or sent is not None
        if sent is not None:
            assert time.monotonic() - sent >= 0.09, "finalizer delay was not awaited"
        print(json.dumps({"scenario": name, "signal": sig.name if sig else None,
                          "acknowledged": acknowledged, "markers": received,
                          "exit": code, "elapsed_ms": round((time.monotonic()-started)*1000),
                          "result": "pass"}), flush=True)
    except BaseException:
        print(json.dumps({"scenario": name, "markers": received, "result": "FAIL"}), flush=True)
        raise
    finally:
        selector.close()
        if child.poll() is None:
            child.kill()
            child.wait()

for sig in (signal.SIGTERM, signal.SIGINT):
    scenario("initializing-" + sig.name, ["--hold-startup"], "acquired", sig,
             "outcome:startup-draining-clean")
    scenario("waiter-cancelled-" + sig.name, ["--hold-startup"], "waiter-timeout", sig,
             "outcome:startup-draining-clean")
    scenario("ready-" + sig.name, [], "ready", sig, "outcome:shutdown-ok", second=modified)
    if modified:
        scenario("second-initializing-" + sig.name, ["--hold-second"], "acquired-second", sig,
                 "outcome:startup-draining-clean", second=True)
if modified:
    scenario("fallible-second-stage", ["--fail-second"], None, None,
             "outcome:startup-application-clean", second=True)
