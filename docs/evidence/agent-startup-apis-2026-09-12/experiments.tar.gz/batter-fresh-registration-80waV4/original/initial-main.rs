use axum::{Router, extract::State, routing::get};
use batter::{
    BoxError, RegistrationError,
    cleanup::CleanupBudget,
    lifecycle::{Registration, ShutdownBudget, Supervisor},
    operation::OperationContext,
    startup::Startup,
};
use std::{net::SocketAddr, sync::{Arc, Mutex}, time::Duration};
use tokio::{io::{AsyncReadExt, AsyncWriteExt}, net::{TcpListener, TcpStream}, sync::{Semaphore, oneshot}};

type Events = Arc<Mutex<Vec<&'static str>>>;

struct HttpLifetime(Events);
impl Drop for HttpLifetime {
    fn drop(&mut self) {
        self.0.lock().unwrap().push("http-state-released");
    }
}

fn register_application_http(
    registration: &mut Registration<'_>,
    listener: TcpListener,
    lifetime: Arc<HttpLifetime>,
) -> Result<(), RegistrationError> {
    let router = Router::new()
        .route("/", get(|State(_lifetime): State<Arc<HttpLifetime>>| async { "served" }))
        .with_state(lifetime);
    registration_probe::concrete_http(registration, "http", listener, router)
}

async fn request(address: SocketAddr) -> Result<String, BoxError> {
    let mut socket = TcpStream::connect(address).await?;
    socket.write_all(b"GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n").await?;
    let mut response = String::new();
    socket.read_to_string(&mut response).await?;
    Ok(response)
}

async fn run() -> Result<(), BoxError> {
    let budget = Duration::from_secs(5);
    let cleanup = CleanupBudget::new(budget, budget, budget)?;
    let supervisor = Supervisor::new(ShutdownBudget::new(budget, budget, budget, cleanup)?);
    let capacity = Arc::new(Semaphore::new(1));
    let acquiring = capacity.clone();
    let events: Events = Arc::new(Mutex::new(Vec::new()));
    let initializing_events = events.clone();
    let (address_tx, address_rx) = oneshot::channel();

    let mut starting = Startup::scoped(
        supervisor, OperationContext::new(budget)?, cleanup,
        move |scope| Box::pin(async move {
            scope.stage("http-resource")?;
            let lifetime = Arc::new(HttpLifetime(initializing_events.clone()));
            let witness = Arc::downgrade(&lifetime);
            let slot = scope.reserve_cleanup("http-resource")?;
            let permit = acquiring.acquire_owned().await?;
            slot.register(move || async move {
                if witness.upgrade().is_some() {
                    return Err(std::io::Error::other("HTTP state still owned at resource finalization").into());
                }
                drop(permit);
                initializing_events.lock().unwrap().push("http-resource-released");
                Ok(())
            });
            let listener = TcpListener::bind("127.0.0.1:0").await?;
            let address = listener.local_addr()?;
            register_application_http(&mut scope.registration(), listener, lifetime)?;
            address_tx.send(address).map_err(|_| std::io::Error::other("address receiver closed"))?;
            Ok::<(), BoxError>(())
        }),
    ).start();
    let running = starting.wait().await?;
    let response = tokio::time::timeout(budget, async {
        running.handle().wait_ready().await.map_err(|_| std::io::Error::other("readiness failed"))?;
        assert_eq!(capacity.available_permits(), 0);
        request(address_rx.await?).await
    }).await;
    let shutdown = running.shutdown().await;
    let response = response??;
    assert!(response.starts_with("HTTP/1.1 200 OK\r\n"));
    assert!(response.ends_with("served"));
    let report = batter::lifecycle::check_shutdown(shutdown)?;
    assert!(report.all_direct_tasks_joined());
    assert_eq!(capacity.available_permits(), 1);
    assert_eq!(*events.lock().unwrap(), ["http-state-released", "http-resource-released"]);
    println!("PASS: loopback HTTP response, successful shutdown, HTTP state ended before explicit resource release");
    Ok(())
}

#[tokio::main]
async fn main() {
    if run().await.is_err() {
        eprintln!("consumer experiment failed");
        std::process::exit(1);
    }
}

