#[cfg(test)]
mod tests {
    use batter::{cleanup::CleanupBudget, lifecycle::{ShutdownBudget, Supervisor}, operation::OperationContext, startup::Startup};
    use std::{sync::{Arc, atomic::{AtomicBool, Ordering}}, time::Duration};
    #[tokio::test]
    async fn current_startup_can_drop_registered_finalizer() {
        let second = Duration::from_secs(1);
        let cleanup = CleanupBudget::new(second, second, second).unwrap();
        let process = Supervisor::new(ShutdownBudget::new(second,second,second,cleanup).unwrap());
        let finalized = Arc::new(AtomicBool::new(false));
        let captured = finalized.clone();
        let mut starting = Startup::new(process, OperationContext::new(second).unwrap(), cleanup, move |scope| Box::pin(async move {
            scope.supervisor().reserve_cleanup("resource").unwrap().register(move || async move {
                captured.store(true, Ordering::SeqCst);
                Ok(())
            });
            drop(scope.supervisor().take_cleanup());
            Err::<(),_>(std::io::Error::other("initialization failed"))
        })).start();
        let failure = match starting.wait().await { Ok(_) => panic!("expected failed startup"), Err(failure) => failure };
        match failure {
            batter::startup::StartupError::Failed(failure) => {
                assert!(failure.cleanup.is_success());
                assert!(failure.cleanup.records.is_empty());
                assert!(!finalized.load(Ordering::SeqCst));
            }
            _ => panic!("expected retained startup failure"),
        }
    }
}
