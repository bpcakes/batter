use crate::{BoxError, RegistrationError, cleanup::CleanupSlot, lifecycle::{Supervisor, ShutdownSignal, ManagedComponent, ManagedSettlement, ManagedShutdownBudget}, operation::OperationContext};
use std::future::Future;

/// Exclusive registration authority. No driver, stack extraction or lifecycle approval.
pub struct Registration<'a> { inner: &'a mut Supervisor }
impl<'a> Registration<'a> {
    pub(crate) fn new(inner: &'a mut Supervisor) -> Self { Self { inner } }
    pub fn register<F, Fut>(&mut self, name: &'static str, factory: F) -> Result<(), RegistrationError>
    where F: FnOnce(ShutdownSignal) -> Fut + Send + 'static, Fut: Future<Output=Result<(), BoxError>> + Send + 'static {
        self.inner.register(name, factory)
    }
    pub fn reserve_cleanup(&mut self, name: &'static str) -> Result<CleanupSlot<'_>, RegistrationError> {
        self.inner.reserve_cleanup(name)
    }
    pub fn register_managed<F, R>(&mut self, name: &'static str, context: OperationContext, factory: F) -> Result<(), RegistrationError>
    where F: FnOnce(ManagedShutdownBudget) -> Result<ManagedComponent<R>, BoxError> + Send + 'static, R: ManagedSettlement {
        self.inner.register_managed(name, context, factory)
    }
}
impl Supervisor {
    pub fn registration(&mut self) -> Registration<'_> { Registration::new(self) }
}

mod sealed { pub trait Sealed {} }
/// Alternative: sealed adapter target, reborrowing only the concrete capability.
pub trait RegistrationTarget: sealed::Sealed {
    fn registration(&mut self) -> Registration<'_>;
}
impl sealed::Sealed for Supervisor {}
impl RegistrationTarget for Supervisor {
    fn registration(&mut self) -> Registration<'_> { self.registration() }
}
impl sealed::Sealed for crate::startup::ProtectedStartupScope {}
impl RegistrationTarget for crate::startup::ProtectedStartupScope {
    fn registration(&mut self) -> Registration<'_> { self.registration() }
}
impl sealed::Sealed for Registration<'_> {}
impl RegistrationTarget for Registration<'_> {
    fn registration(&mut self) -> Registration<'_> { Registration::new(self.inner) }
}
