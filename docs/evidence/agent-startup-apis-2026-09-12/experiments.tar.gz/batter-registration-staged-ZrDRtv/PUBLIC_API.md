# Candidate: protected startup registration

Use Rust 1.98.1 explicitly. Add `batter = { path = "/tmp/batter-registration-staged-ZrDRtv/core" }`
to an isolated package manifest with its own `[workspace]`. This is an experimental
API, not a released library change.

Use `Startup::scoped(supervisor, context, cleanup_budget, |scope| Box::pin(async move { ... }))`
for canonical service initialization, then `.start()`. The callback receives
`&mut ProtectedStartupScope`, with the same ordinary boxed native future and
concrete error result as existing `Startup::new`. `.without_readiness_approval()`
remains available when staged application readiness is required. Keep the startup
owner until `wait()` returns the running owner; borrowed waiter cancellation does
not cancel initialization or cleanup. Finalization outcomes remain in native reports.

The protected scope offers:

- `stage(&mut self, &'static str) -> Result<(), RegistrationError>` sets validated
  static diagnostics metadata.
- `reserve_cleanup(&mut self, &'static str) -> Result<CleanupSlot<'_>, RegistrationError>`
  validates registration before acquisition. Hold the slot across acquisition,
  then immediately register acquired ownership before another await. It cannot
  reject successful registration. Dropping an unused slot registers nothing.
- `registration(&mut self) -> Registration<'_>` lends component registration.

The concrete borrowed `Registration` offers the existing Supervisor operations
`register`, `register_managed`, and `reserve_cleanup`, with their existing names,
generic bounds and results. It exposes no Supervisor reference, driver start,
cleanup extraction, readiness approval, or public constructor/fields. It owns no
independent tasks or finalizers. Dropping the view simply ends its borrow.

Use `register` for direct critical tasks and acknowledge actual initialization
through the supplied shutdown signal. Use supported native adapter functions
for runtimes with descendants; `register_managed` is the adapter-author boundary.

`Supervisor::registration()` supplies the same borrowed view outside owned startup.
The sealed `RegistrationTarget` trait exposes only `registration() -> Registration<'_>`
and is implemented by `Supervisor`, `ProtectedStartupScope`, and `Registration`.
Adapters can accept `&mut impl RegistrationTarget`, so call expressions can pass
`scope`, `&mut supervisor`, or `&mut view`. Application-defined implementations
are unavailable. Cleanup-only adapters need no component registration authority.

The experiment's `registration-probe` package offers two HTTP candidate functions
with native `TcpListener` and `axum::Router` arguments:

```
concrete_http(&mut Registration<'_>, name, listener, router)
generic_http(&mut impl RegistrationTarget, name, listener, router)
```

Both return `Result<(), RegistrationError>`, transfer native listener/router
ownership into critical process supervision, and leave listener binding,
signals, runtime, budgets and application policy explicit.

The older `Startup::new` and `StartupScope::supervisor()` remain available for
compatibility as a legacy low-level route. Extracted/replaced ownership on that
route leaves the owner's cleanup contract. The protected callback type never
exposes that route. This staging shares the existing lifecycle driver.

This capability does not supervise arbitrary `tokio::spawn` calls, prove remote
effects, provide async Drop, bound response streaming, or survive runtime death.
SQLx protected acquisition and integrated startup signals are outside this prototype.
