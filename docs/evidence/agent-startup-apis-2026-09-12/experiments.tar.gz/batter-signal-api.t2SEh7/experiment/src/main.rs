use batter::{cleanup::CleanupBudget, lifecycle::{Supervisor, ShutdownBudget}, operation::OperationContext, startup::{StartupCause, StartupError, StartupOutcome}};
use signal_api_experiment::{SignalStartup, Injection, InitializeError, start_with_unix_signals};
use std::{io::{BufRead, BufReader, Write}, process::{Command, Stdio}, sync::{Arc, atomic::{AtomicUsize, Ordering}}, time::{Duration, Instant}};

fn emit(s: &str) { println!("{s}"); std::io::stdout().flush().unwrap(); }

fn constrain_initializer<F>(initialize: F) -> F
where F: for<'a> FnOnce(&'a mut batter::startup::StartupScope) -> batter::startup::StartupFuture<'a, batter::RegistrationError> { initialize }

async fn child(mode: String) {
    let second = Duration::from_secs(1);
    let cleanup = CleanupBudget::new(second, second, second).unwrap();
    let mut supervisor = Supervisor::new(ShutdownBudget::new(second, second, second, cleanup).unwrap());
    let cleaned = Arc::new(AtomicUsize::new(0));
    let finalizer_count = cleaned.clone();
    supervisor.on_cleanup("prior.resource", move || async move {
        finalizer_count.fetch_add(1, Ordering::SeqCst);
        emit("cleanup-complete");
        Ok(())
    }).unwrap();
    if mode == "duplicate-before" {
        supervisor.register("signals", |signal| async move { signal.mark_started(); signal.draining().await; Ok(()) }).unwrap();
    }
    let initialize_mode = mode.clone();
    let initialized = Arc::new(AtomicUsize::new(0));
    let initialize_count = initialized.clone();
    let initializer = constrain_initializer(move |scope| {
        Box::pin(async move {
            initialize_count.fetch_add(1, Ordering::SeqCst);
            if initialize_mode == "duplicate-during" {
                scope.supervisor().register("signals", |signal| async move { signal.mark_started(); signal.draining().await; Ok(()) })?;
            }
            scope.supervisor().register("application", |signal| async move { signal.mark_started(); signal.draining().await; Ok(()) })?;
            emit("initializer-entered");
            if matches!(initialize_mode.as_str(), "during-term" | "during-int" | "owner-loss" | "waiter-loss" | "helper-during" | "before-first-poll-protected") {
                std::future::pending::<()>().await;
            }
            Ok(())
        })
    });
    let context = OperationContext::new(Duration::from_secs(5)).unwrap();
    let mut starting = if mode == "helper-during" {
        start_with_unix_signals(supervisor, context, cleanup, "signals", initializer)
    } else {
        SignalStartup::new(supervisor, context, cleanup, initializer).with_unix_signals("signals").inject(match mode.as_str() {
            "install-failure" => Injection::InstallFailure,
            "handoff-term" => Injection::HandoffGate,
            "before-first-poll-protected" => Injection::SynchronousInstall,
            _ => Injection::None,
        }).start()
    };
    let observer = starting.observer();
    if mode == "before-first-poll" {
        emit("launch-returned");
        let mut line = String::new();
        std::io::stdin().read_line(&mut line).unwrap();
        panic!("negative control must die before runtime polls coordinator");
    }
    if mode == "before-first-poll-protected" {
        emit("launch-returned");
        let mut line = String::new();
        std::io::stdin().read_line(&mut line).unwrap();
        assert_eq!(line.trim(), "release");
    }
    if mode == "queued-owner-loss" {
        assert!(matches!(observer.wait().await, StartupOutcome::Running(_)));
        drop(starting);
    } else if mode == "owner-loss" {
        tokio::time::sleep(Duration::from_millis(30)).await;
        drop(starting);
    } else {
        if mode == "waiter-loss" {
            assert!(tokio::time::timeout(Duration::from_millis(30), starting.wait()).await.is_err());
            assert_eq!(cleaned.load(Ordering::SeqCst), 0);
            emit("waiter-cancelled");
        }
        match starting.wait().await {
            Err(StartupError::Failed(failure)) => {
                match mode.as_str() {
                    "install-failure" => assert!(matches!(failure.cause, StartupCause::Failed(InitializeError::Signals(batter::lifecycle::SignalRegistrationError::Install(_))))),
                    "duplicate-before" | "duplicate-during" => assert!(matches!(failure.cause, StartupCause::Failed(InitializeError::Signals(batter::lifecycle::SignalRegistrationError::Registration(_))))),
                    _ => assert!(matches!(failure.cause, StartupCause::Draining)),
                }
                assert_eq!(failure.cleanup.records.len(), 1);
                assert!(failure.cleanup.is_success());
                emit("startup-failed-cleanly");
            }
            Err(other) => panic!("unexpected coordinator failure {other:?}"),
            Ok(running) => {
                assert!(mode == "handoff-term" || mode == "running-term" || mode == "running-owner-loss");
                if mode == "running-owner-loss" {
                    let observation = running.observer();
                    drop(running);
                    assert!(observation.wait().await.unwrap().is_success());
                } else {
                    emit("running-owner");
                    assert!(running.wait().await.unwrap().is_success());
                }
                emit("running-stopped-cleanly");
            }
        }
    }
    match observer.wait().await {
        StartupOutcome::Failed(_) => {},
        StartupOutcome::Running(observation) => assert!(observation.wait().await.unwrap().is_success()),
    }
    assert_eq!(cleaned.load(Ordering::SeqCst), 1);
    if mode == "duplicate-before" || mode == "install-failure" { assert_eq!(initialized.load(Ordering::SeqCst), 0); }
    if mode == "duplicate-during" { assert_eq!(initialized.load(Ordering::SeqCst), 1); emit("late-duplicate-confirmed"); }
    emit("child-pass");
}

fn suite() {
    for mode in ["during-term", "during-int", "helper-during", "handoff-term", "running-term", "install-failure", "duplicate-before", "duplicate-during", "owner-loss", "waiter-loss", "queued-owner-loss", "running-owner-loss", "before-first-poll", "before-first-poll-protected"] {
        let mut child = Command::new(std::env::current_exe().unwrap()).arg(mode).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::inherit()).spawn().unwrap();
        let stdout = child.stdout.take().unwrap();
        let (sender, receiver) = std::sync::mpsc::channel();
        let reader = std::thread::spawn(move || {
            for line in BufReader::new(stdout).lines() { if sender.send(line.unwrap()).is_err() { break; } }
        });
        let deadline = Instant::now() + Duration::from_secs(8);
        let trigger = match mode { "handoff-term" => "handoff-gate", "running-term" => "running-owner", "waiter-loss" => "waiter-cancelled", "before-first-poll" | "before-first-poll-protected" => "launch-returned", _ => "initializer-entered" };
        let send_signal = matches!(mode, "during-term" | "during-int" | "helper-during" | "handoff-term" | "running-term" | "waiter-loss" | "before-first-poll" | "before-first-poll-protected");
        let mut sent = false;
        let mut lines = Vec::new();
        loop {
            if Instant::now() >= deadline { child.kill().unwrap(); child.wait().unwrap(); panic!("{mode}: deadline, lines={lines:?}"); }
            if let Ok(line) = receiver.recv_timeout(Duration::from_millis(10)) {
                if line == trigger && send_signal && !sent {
                    let flag = if mode == "during-int" { "-INT" } else { "-TERM" };
                    assert!(Command::new("kill").args([flag, &child.id().to_string()]).status().unwrap().success());
                    sent = true;
                    if mode == "handoff-term" || mode == "before-first-poll-protected" { writeln!(child.stdin.as_mut().unwrap(), "release").unwrap(); }
                }
                lines.push(line);
            }
            if let Some(status) = child.try_wait().unwrap() {
                reader.join().unwrap();
                lines.extend(receiver.try_iter());
                if mode == "before-first-poll" {
                    use std::os::unix::process::ExitStatusExt;
                    assert_eq!(status.signal(), Some(15), "negative control {mode}: {status}, {lines:?}");
                    assert!(!lines.iter().any(|l| l == "cleanup-complete"));
                } else {
                    assert!(status.success(), "{mode}: {status}, {lines:?}");
                    assert!(lines.iter().any(|l| l == "child-pass"), "{mode}: missing pass, {lines:?}");
                }
                if send_signal { assert!(sent); }
                println!("PASS {mode}: {}", lines.join(", "));
                break;
            }
        }
    }
}

fn main() {
    if let Some(mode) = std::env::args().nth(1) {
        tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap().block_on(child(mode));
    } else { suite(); }
}
