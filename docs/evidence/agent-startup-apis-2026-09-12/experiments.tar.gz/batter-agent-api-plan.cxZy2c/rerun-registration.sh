#!/usr/bin/env bash
set -euo pipefail
export RUSTUP_TOOLCHAIN=1.98.1
export CARGO_TARGET_DIR=/home/aa/Documents/batter/target
export TMPDIR=/home/aa/.cache
cd /home/aa/.cache/batter-agent-api-plan.cxZy2c
manifest=/tmp/batter-registration-staged-ZrDRtv/Cargo.toml
cargo test --manifest-path "$manifest" -p registration-probe --lib --offline --locked
cargo check --manifest-path "$manifest" -p registration-probe --example managed --example staged_legacy --offline --locked
for spec in extract:E0599 start:E0599 replace:E0308 escape:E0521 temporary_slot:E0716 forge:E0277 wrapper_compatibility:E0277 staged_protected:E0599; do
  case_name=${spec%%:*}
  expected_code=${spec##*:}
  if cargo check --manifest-path "$manifest" -p registration-probe --example "$case_name" --offline --locked >"parent-$case_name.log" 2>&1; then
    printf 'UNEXPECTED SUCCESS: %s\n' "$case_name"
    exit 1
  fi
  rg -q "error\[$expected_code\]" "parent-$case_name.log"
  printf 'EXPECTED REJECTION: %s (%s)\n' "$case_name" "$expected_code"
done
