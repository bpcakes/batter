# Protected PostgreSQL pool creation experiment

Executed on Linux with Rust 1.98.1, SQLx 0.9.0, Tokio 1.53.1 and PostgreSQL
18.6 (Ubuntu 18.6-1.pgdg24.04+2). This is a scratch experiment, not production
API implementation or a workspace verification receipt. No production sources,
tracker entries, or existing databases were changed by this experiment.

## Findings and preferred shape

Prefer Candidate A, a synchronous slot-consuming adapter function, initially
named `pool_in` in this prototype; a production name such as
`registered_lazy_pool` should advertise both registration and lazy semantics.
It is a small adapter primitive applicable to existing Command scopes and
proposed restricted Startup scopes. Consuming CleanupSlot validates a cleanup
name before creating a pool and makes hook registration infallible afterward.
It returns native PgPool and preserves native options, callback behavior,
typed failures from subsequent operations, and independent owner cleanup.
There is no reason to expose mutable Supervisor to this adapter.

Candidate B, a scope extension trait, saves spelling but duplicates scope
implementations/import requirements and requires an additional trait API.
It adds no lifecycle invariant over Candidate A. Its invalid/duplicate-name
test demonstrates the same validation boundary, not an advantage of the trait.

Candidate C, an async connect helper, genuinely removes an acquisition/probe
step for consumers who require initial authentication. Its implementation is
possible and the failure/cancellation tests pass. It creates and registers a
lazy pool before one bounded native acquire, but does not reproduce native
`connect_with` minimum-connection warmup. Native `connect_with` constructs its
pool internally, making pre-await ownership registration unavailable to an
external adapter that invokes it directly. Calling a function `connect_with`
while silently replacing these semantics would be misleading.

The async helper also introduces a context parameter and policy question:
acquire-only checks authentication, SELECT 1 checks a query, and application
schema/migration readiness remains separate. Candidate A composes with existing
`batter_sqlx::probe` when callers need that query. The adapter's core ownership
gap does not require a new async connect API. Fresh consumer experiments should
determine whether removing a single explicit probe materially prevents repeated
misuse before selecting C as an additional supported convenience.

## Contract boundaries requiring exact wording

SQLx lazy construction may launch maintenance/min-connection work immediately.
The guarantee is name validation before construction and hook publication in
the same synchronous call before returning the pool or awaiting initialization.
Do not claim no SQLx task can run before publication on another runtime thread.
The outer unstarted owned factory is inert, not every native option constructor.

`PgConnectOptions::new_without_pgpass` still reads PostgreSQL environment
variables. It only omits pgpass access. Supplying native options must not be
described as ambient-environment-free. Existing explicit settings constructors
remain application-owned; the adapter should not parse a URL or change options.

Pool close marks the pool closed immediately when its method is called, but
the returned future must complete before claiming accounted client closure.
Retained checked-out connections delay completion. One test deliberately holds
such a connection and verifies a TimedOut cleanup record despite is_closed=true.
Detached native sessions remain outside pool accounting. No test here asserts
server-session termination, rollback, remote cancellation, or durability.

Finalizer ordering is registration order reversed. Errors before any pool exists
register no pool hook; errors after construction retain its hook. Work errors
and previous cleanup errors remain concrete in owner reports. Cleanup still
uses existing bounded/skip semantics and is not made unconditional or unbounded.

## Executed evidence

`src/lib.rs` contains three scratch candidates and thirteen executable tests.
The six-test first run passed. Expansion initially failed to compile because
the experiment used nonexistent OperationContext::cancellation; this was fixed
to the existing public cancel method. Eleven and final thirteen-test runs passed.

The thirteen cases are:

1. Invalid and duplicate name rejection before TCP connection work.
2. Dropping an unstarted owner does not construct a pool.
3. Both synchronous API spellings return a native pool usable for SELECT 42 and
   close it while an external pool clone remains.
4. Failed first probe retains native SQLx failure and earlier typed cleanup error.
5. Owner cancellation during pending native acquisition still closes pool.
6. Two used pools close after their dependent finalizer in exact LIFO order.
7. Async helper missing-role authentication failure retains SQLSTATE 28000 and cleanup.
8. Synchronous lazy success is distinguished from first probe authentication failure.
9. Async acquisition succeeds, later work fails concretely, pool still closes.
10. Async helper interrupted in stalled protocol handshake retains close finalizer.
11. Never-polled helper and pre-cancelled context register no pool hook.
12. Retained native connection yields reported cleanup timeout, not false success.
13. Native pool configuration, after_connect callback, and application_name survive.

The missing-role test exercises a real server rejection under local trust auth;
it is not a password/SCRAM/TLS test. Handshake cancellation uses an isolated
loopback TCP listener that accepts and stalls, not an existing database. The
connection-refused case uses a released ephemeral port; a concurrent local bind
could theoretically race it. No flaky run was observed; production tests should
prefer the controlled listener when error subtype is not the property under test.

These are implementation contract experiments, not usability statistics. There
has not yet been an independent fresh-agent consumer task for these candidates.
No macOS, minimum-toolchain, full workspace, Jig, or remote CI claim is made.

## Native source grounding

Installed Cargo registry source was inspected at exact version 0.9.0:

- sqlx-core/src/pool/options.rs:537: connect_with initializes min_connections
  before acquire and releases a native connection through an internal method.
- sqlx-core/src/pool/options.rs:579: connect_lazy_with calls PoolInner::new_arc.
- sqlx-core/src/pool/inner.rs:507: maintenance task spawning and min-connections behavior.
- sqlx-core/src/pool/mod.rs:441 and inner.rs:96: close marks closure synchronously
  and returns a future awaiting pool-accounted permits/connections.
- sqlx-postgres/src/options/mod.rs:65: new_without_pgpass reads PG environment.

The docs.rs exact-version pages were attempted through browsing but rejected by
the web tool as unavailable/unsafe-to-open; claims above are grounded in installed
native source, not a successfully retrieved web page. URLs to recheck when
recording repository primary sources: https://docs.rs/sqlx/0.9.0/sqlx/pool/struct.PoolOptions.html
and https://docs.rs/sqlx/0.9.0/sqlx/struct.Pool.html .

## Rerun and isolate

Only this scratch cluster is owned by this experiment. It is intentionally left
running for the parent's fresh consumer task and listens solely on the Unix
socket directory /tmp/batter-pool-api.WWWDTk, port 55439. No TCP listener is
configured. That mktemp-created directory is private to the user. Cluster data:
/home/aa/.cache/batter-pool-api.XDZEQM/pgdata . User pool_test, database postgres,
local trust authentication, no password needed. Test options explicitly set
socket host, port, username, database, SSL Disabled; no DATABASE_URL is read.

```sh
CARGO_TARGET_DIR=/home/aa/.cache/batter-pool-api.XDZEQM/target cargo test --manifest-path /home/aa/.cache/batter-pool-api.XDZEQM/Cargo.toml --offline
/usr/lib/postgresql/18/bin/pg_ctl -D /home/aa/.cache/batter-pool-api.XDZEQM/pgdata status
/usr/lib/postgresql/18/bin/pg_ctl -D /home/aa/.cache/batter-pool-api.XDZEQM/pgdata stop -m fast
```

If restarting after shutdown, reuse the exact isolated target:

```sh
/usr/lib/postgresql/18/bin/pg_ctl -D /home/aa/.cache/batter-pool-api.XDZEQM/pgdata -l /home/aa/.cache/batter-pool-api.XDZEQM/postgres.log -o '-k /tmp/batter-pool-api.WWWDTk -h "" -p 55439' start
```

Initial initdb on /tmp failed with ENOSPC because the root filesystem had 31 MB
free. initdb removed its own partial data directory. Retained initdb.log describes
progress; the original stderr FATAL could not write base/4/1255: No space left on
device is recorded in the tool transcript. Relocating cluster data/build artifacts
to a fresh home-cache scratch directory succeeded. No unrelated file was deleted.

Minimal archive: Cargo.toml, Cargo.lock, src/lib.rs, PUBLIC_API.md, RESEARCH.md,
test-expanded.log (initial compile failure), test-final.log (11 pass),
test-thirteen.log (13 pass), initdb.log, initdb-retry.log. Do not archive pgdata
or target. Generalize hardcoded scratch socket/path only when archiving a runnable
fixture; record that archive transformation and rerun it if claiming it executed.

## Suggested delivery acceptance

One adapter delivery task can introduce the sync consuming-slot constructor,
native rustdoc example in both owned lifecycles, failure tests, and guidance.
Depend on constrained StartupScope reservation delivery if the canonical Startup
example must avoid supervisor(). Do not add a generic acquire/finalize framework.

Acceptance must preserve all thirteen relevant contracts above, covering the
selected API rather than maintaining unused candidates. Run parent two-toolchain
verification, rustdoc/HTTP smoke and final Jig receipts for production changes.
Keep provisioning exclusively in external experimental or opt-in test fixtures.
Update adapter README, usage/integrations/guarantees/status and owning Bead with
new precise semantics; include all fixtures in Jig v9 input scopes.

Migrate reference-service register_pool and postgres-lifecycle composition to
the selected constructor. Preserve explicit connect_options_from_process()
ownership and application probe/migration ordering. Search finite command paths
as well as service paths. Retain existing register_pool_close only as a clearly
documented low-level existing-pool escape hatch, or stage a deliberate public-API
compatibility change; never imply it has the new creation ownership guarantee.
