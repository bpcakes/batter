//! Isolated API-shape prototype, using only public Batter APIs.
use batter::{cleanup::CleanupBudget, lifecycle::{Supervisor, SignalRegistrationError, InstalledSignals, install_signals}, operation::OperationContext, startup::{Startup, StartupScope, StartupFuture, StartingSupervisor}};

#[derive(Debug)]
pub enum InitializeError<E> { Application(E), Signals(SignalRegistrationError) }

/// Candidate A: inert policy selected on the existing ownership-shaped builder.
/// This wrapper stands in for a native Startup::with_unix_signals method.
pub struct SignalStartup<F> {
    supervisor: Supervisor,
    context: OperationContext,
    cleanup: CleanupBudget,
    initialize: F,
    name: &'static str,
    injection: Injection,
}

#[derive(Clone, Copy, Default)]
pub enum Injection { #[default] None, InstallFailure, HandoffGate, SynchronousInstall }

impl<F> SignalStartup<F> {
    pub fn new<E>(supervisor: Supervisor, context: OperationContext, cleanup: CleanupBudget, initialize: F) -> Self
    where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> {
        Self { supervisor, context, cleanup, initialize, name: "signals", injection: Injection::None }
    }
    pub fn with_unix_signals(mut self, name: &'static str) -> Self { self.name = name; self }
    /// Fixture-only seam, absent from the proposed public API.
    pub fn inject(mut self, injection: Injection) -> Self { self.injection = injection; self }
    pub fn start<E>(self) -> StartingSupervisor<InitializeError<E>>
    where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> + Send + 'static, E: Send + Sync + 'static {
        let Self { supervisor, context, cleanup, initialize, name, injection } = self;
        let handle = supervisor.handle();
        let early = matches!(injection, Injection::SynchronousInstall).then(|| fixture_install(&supervisor, name, injection));
        Startup::new(supervisor, context, cleanup, move |scope| Box::pin(async move {
            scope.stage("signals.install").expect("valid static fixture stage");
            let mut signals = early.unwrap_or_else(|| fixture_install(scope.supervisor(), name, injection)).map_err(InitializeError::Signals)?;
            tokio::select! {
                biased;
                _ = signals.received() => { handle.request(); return Ok(()); }
                result = initialize(scope) => result.map_err(InitializeError::Application)?,
            }
            if matches!(injection, Injection::HandoffGate) {
                println!("handoff-gate");
                use std::io::Write;
                std::io::stdout().flush().unwrap();
                // Deliberately leave the installed sources unpolled across this gap.
                // Parent sends TERM, then releases via stdin. No production gate.
                tokio::task::spawn_blocking(|| {
                    let mut line = String::new();
                    std::io::stdin().read_line(&mut line).unwrap();
                    assert_eq!(line.trim(), "release");
                }).await.unwrap();
            }
            signals.register(scope.supervisor()).map_err(InitializeError::Signals)?;
            Ok(())
        })).start()
    }
}

fn fixture_install(supervisor: &Supervisor, name: &'static str, injection: Injection) -> Result<InstalledSignals, SignalRegistrationError> {
    if matches!(injection, Injection::InstallFailure) {
        // Native installation of an invalid negative signal fails with io::Error.
        let invalid = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::from_raw(-1));
        return Err(SignalRegistrationError::Install(invalid.expect_err("invalid signal must fail")));
    }
    install_signals(supervisor, name)
}

/// Candidate B: separate root helper. Same engine; duplicated startup policy args.
pub fn start_with_unix_signals<F, E>(supervisor: Supervisor, context: OperationContext, cleanup: CleanupBudget, name: &'static str, initialize: F) -> StartingSupervisor<InitializeError<E>>
where F: for<'a> FnOnce(&'a mut StartupScope) -> StartupFuture<'a, E> + Send + 'static, E: Send + Sync + 'static {
    SignalStartup::new(supervisor, context, cleanup, initialize).with_unix_signals(name).start()
}
