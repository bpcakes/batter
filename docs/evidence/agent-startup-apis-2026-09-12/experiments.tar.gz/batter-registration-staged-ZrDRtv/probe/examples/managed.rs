use batter::{BoxError, RegistrationError, operation::OperationContext, lifecycle::{ManagedComponent, ManagedSettlement}, registration::Registration};
use runledger_runtime::{PreparedSupervisor, RuntimeShutdownBudget, RuntimeShutdownReport};
#[derive(Debug)]
struct NativeReport(RuntimeShutdownReport);
impl ManagedSettlement for NativeReport {
    fn is_success(&self) -> bool { self.0.is_success() }
    fn allows_dependency_cleanup(&self) -> bool { self.0.is_cooperatively_stopped() }
}
fn register(target: &mut Registration<'_>, prepared: PreparedSupervisor, startup: OperationContext) -> Result<(), RegistrationError> {
    target.register_managed("worker", startup, move |budget| {
        let budget = RuntimeShutdownBudget::new(budget.graceful(), budget.abort())?;
        let native = prepared.start();
        let initialization = native.startup_observer();
        let stop = native.shutdown_handle();
        let stopping = stop.clone();
        Ok(ManagedComponent::new(
            async move { initialization.wait_initialized().await.map_err(|e| Box::new(e) as BoxError) },
            async move { stopping.requested().await },
            move |started| stop.request_shutdown_since(started),
            async move { NativeReport(native.run_until_shutdown_report(std::future::pending(), budget).await) },
        ))
    })
}
fn main() { let _ = register; }
