import os
import selectors
import signal
import subprocess
import time

ROOT = "/home/aa/.cache/batter-fresh-signal-consumer.SNhjhs"

def run(binary, flags, checkpoint, sig, expected, second=False):
    child = subprocess.Popen([binary, *flags], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    selector = selectors.DefaultSelector()
    selector.register(child.stdout, selectors.EVENT_READ)
    lines, pending, sent = [], b"", False
    deadline = time.monotonic() + 8
    try:
        while not sent:
            remaining = deadline - time.monotonic()
            assert remaining > 0, ("missing checkpoint", checkpoint, lines)
            events = selector.select(remaining)
            assert events, ("checkpoint timeout", checkpoint, lines)
            chunk = os.read(child.stdout.fileno(), 4096)
            assert chunk, ("EOF before signal", checkpoint, lines)
            pending += chunk
            while b"\n" in pending:
                line, pending = pending.split(b"\n", 1)
                lines.append(line.decode())
            if checkpoint in lines:
                assert "cleanup" not in lines, ("premature cleanup", lines)
                os.kill(child.pid, sig)
                sent = True
        tail, errors = child.communicate(timeout=max(0.1, deadline-time.monotonic()))
        lines.extend((pending+tail).decode().splitlines())
        assert child.returncode == 0, (child.returncode, lines, errors)
        assert errors == b"", errors
        assert lines.count("cleanup") == 1, lines
        assert lines.count(expected) == 1, lines
        assert lines.index("cleanup") < lines.index(expected), lines
        assert not any("private" in line for line in lines), lines
        if checkpoint != "ready":
            assert "ready" not in lines, lines
        if second:
            assert lines.count("cleanup-second") == 1, lines
            assert lines.index("cleanup-second") < lines.index("cleanup"), lines
        print("PASS", os.path.basename(binary), flags, checkpoint, sig.name, expected)
    finally:
        selector.close()
        if child.poll() is None:
            child.kill()
            child.communicate(timeout=3)

count = 0
for variant in ["initial", "modified"]:
    binary = f"{ROOT}/{variant}/consumer"
    for sig in [signal.SIGTERM, signal.SIGINT]:
        for checkpoint in ["acquired", "waiter-timeout"]:
            run(binary, ["--hold-startup"], checkpoint, sig, "outcome:startup-draining-clean")
            count += 1
        run(binary, [], "ready", sig, "outcome:shutdown-ok", variant == "modified")
        count += 1
        if variant == "modified":
            run(binary, ["--hold-second"], "acquired-second", sig,
                "outcome:startup-draining-clean", True)
            count += 1
assert count == 14
print("PASS all", count, "independent parent signal cases")
