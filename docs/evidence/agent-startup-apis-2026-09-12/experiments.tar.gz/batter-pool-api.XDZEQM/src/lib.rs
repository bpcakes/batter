use batter::{cleanup::CleanupSlot, command::CommandScope, RegistrationError};
use sqlx::{PgPool, postgres::{PgPoolOptions, PgConnectOptions}};

/// Candidate A: pool creation and cleanup registration are one synchronous step.
/// The owner of the supplied slot drives close; SQLx options retain native semantics.
/// Use in the owned Startup/Command callback, then await native work or an explicit probe.
pub fn pool_in(slot: CleanupSlot<'_>, options: PgPoolOptions, connection: PgConnectOptions) -> PgPool {
    let pool = options.connect_lazy_with(connection);
    let closing = pool.clone();
    slot.register(move || async move { closing.close().await; Ok(()) });
    pool
}

/// Candidate C: register before bounded first acquisition; does not execute SELECT 1.
/// This establishes one authenticated native connection, not schema readiness or all min_connections.
pub async fn connect_in(slot: CleanupSlot<'_>, options: PgPoolOptions, connection: PgConnectOptions, context: &batter::operation::OperationContext)
 -> Result<PgPool, batter::operation::OperationError<batter_sqlx::SqlxFailure>> {
    context.run("postgres.connect", |_| async move {
        let pool = pool_in(slot, options, connection);
        let conn = pool.acquire().await.map_err(batter_sqlx::SqlxFailure::from)?;
        drop(conn);
        Ok(pool)
    }).await
}

/// Candidate B: scope extension convenience. This would need a second impl for StartupScope.
pub trait PgPoolScopeExt {
    fn open_pool(&mut self, name: &'static str, options: PgPoolOptions, connection: PgConnectOptions) -> Result<PgPool, RegistrationError>;
}
impl PgPoolScopeExt for CommandScope {
    fn open_pool(&mut self, name: &'static str, options: PgPoolOptions, connection: PgConnectOptions) -> Result<PgPool, RegistrationError> {
        Ok(pool_in(self.reserve_cleanup(name)?, options, connection))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use batter::{cleanup::{CleanupBudget, CleanupOutcome}, command::{Command, CommandCause}, operation::OperationContext};
    use std::{sync::{Arc, Mutex}, time::Duration};
    use sqlx::postgres::PgSslMode;

    fn budget() -> CleanupBudget { CleanupBudget::new(Duration::from_secs(3), Duration::from_secs(2), Duration::from_secs(1)).unwrap() }
    fn context() -> OperationContext { OperationContext::new(Duration::from_secs(8)).unwrap() }
    fn connection() -> PgConnectOptions { PgConnectOptions::new_without_pgpass().host("/tmp/batter-pool-api.WWWDTk").port(55439).username("pool_test").database("postgres").ssl_mode(PgSslMode::Disable) }
    fn options() -> PgPoolOptions { PgPoolOptions::new().max_connections(2).acquire_timeout(Duration::from_millis(300)) }

    #[tokio::test]
    async fn rejects_names_without_connecting() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let opts = || connection().host("127.0.0.1").port(port);
            assert!(scope.open_pool("", options().min_connections(1).idle_timeout(None).max_lifetime(None), opts()).is_err());
            scope.reserve_cleanup("duplicate").unwrap().register(|| async { Ok(()) });
            assert!(scope.open_pool("duplicate", options().min_connections(1).idle_timeout(None).max_lifetime(None), opts()).is_err());
            Ok::<_, RegistrationError>(())
        })).start().wait().await.unwrap();
        assert!(report.is_success());
        assert_eq!(report.cleanup.as_ref().unwrap().records.len(), 1);
        assert!(tokio::time::timeout(Duration::from_millis(100), listener.accept()).await.is_err());
    }

    #[tokio::test]
    async fn owned_unpolled_spec_constructs_no_pool() {
        let calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let observed = calls.clone();
        let spec = Command::new(context(), budget(), move |scope| Box::pin(async move {
            calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            let _pool = pool_in(scope.reserve_cleanup("pool")?, options(), connection());
            Ok::<_, RegistrationError>(())
        }));
        drop(spec);
        assert_eq!(observed.load(std::sync::atomic::Ordering::SeqCst), 0);
    }

    #[tokio::test]
    async fn both_shapes_return_native_pool_used_then_closed() {
        for extension in [false, true] {
            let observed = Arc::new(Mutex::new(None));
            let published = observed.clone();
            let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
                let pool = if extension { scope.open_pool("pool", options(), connection())? }
                    else { pool_in(scope.reserve_cleanup("pool")?, options(), connection()) };
                *published.lock().unwrap() = Some(pool.clone());
                let answer: i32 = sqlx::query_scalar("SELECT 42::int4").fetch_one(&pool).await.unwrap();
                Ok::<_, RegistrationError>(answer)
            })).start().wait().await.unwrap();
            assert!(report.is_success());
            assert_eq!(report.work.as_ref().unwrap(), &42);
            assert!(observed.lock().unwrap().as_ref().unwrap().is_closed());
        }
    }

    #[tokio::test]
    async fn failed_probe_retains_native_error_and_prior_cleanup_error() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        drop(listener);
        let observed = Arc::new(Mutex::new(None));
        let published = observed.clone();
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            scope.reserve_cleanup("prior").unwrap().register(|| async { Err(Box::new(std::io::Error::other("private-cleanup-marker")) as batter::BoxError) });
            let pool = pool_in(scope.reserve_cleanup("pool").unwrap(), options(), connection().host("127.0.0.1").port(port));
            *published.lock().unwrap() = Some(pool.clone());
            batter_sqlx::probe(&pool, &context()).await
        })).start().wait().await.unwrap();
        assert!(matches!(&report.work, Err(CommandCause::Failed(batter::operation::OperationError::Failed(failure))) if matches!(failure.native(), sqlx::Error::Io(_) | sqlx::Error::PoolTimedOut)));
        let cleanup = report.cleanup.as_ref().unwrap();
        assert_eq!(cleanup.records.iter().map(|r| r.name).collect::<Vec<_>>(), ["pool", "prior"]);
        assert_eq!(cleanup.records[0].outcome, CleanupOutcome::Succeeded);
        assert!(cleanup.records[1].error.as_ref().unwrap().downcast_ref::<std::io::Error>().is_some());
        assert!(!format!("{report:?}").contains("private-cleanup-marker"));
        assert!(observed.lock().unwrap().as_ref().unwrap().is_closed());
    }

    #[tokio::test]
    async fn cancelled_pending_native_acquisition_still_closes_pool() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let observed = Arc::new(Mutex::new(None));
        let published = observed.clone();
        let command = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let pool = pool_in(scope.reserve_cleanup("pool").unwrap(), options().acquire_timeout(Duration::from_secs(20)), connection().host("127.0.0.1").port(port));
            *published.lock().unwrap() = Some(pool.clone());
            let _conn = pool.acquire().await.unwrap();
            Ok::<_, RegistrationError>(())
        })).start();
        let (_socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept()).await.unwrap().unwrap();
        let observer = command.observer();
        drop(command);
        let report = observer.wait().await.unwrap();
        assert!(matches!(report.work, Err(CommandCause::Interrupted(_))));
        assert!(report.cleanup.as_ref().unwrap().is_success());
        assert!(observed.lock().unwrap().as_ref().unwrap().is_closed());
    }

    #[tokio::test]
    async fn reverse_order_closes_two_pools_after_dependent_cleanup() {
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let first = pool_in(scope.reserve_cleanup("first")?, options(), connection());
            let first_checked = first.clone();
            let second = pool_in(scope.reserve_cleanup("second")?, options(), connection());
            let second_checked = second.clone();
            sqlx::query("SELECT 1").execute(&first).await.unwrap();
            sqlx::query("SELECT 1").execute(&second).await.unwrap();
            scope.reserve_cleanup("dependent")?.register(move || async move {
                assert!(!first_checked.is_closed()); assert!(!second_checked.is_closed()); Ok(())
            });
            Ok::<_, RegistrationError>((first, second))
        })).start().wait().await.unwrap();
        assert!(report.is_success());
        let (first, second) = report.work.as_ref().unwrap();
        assert!(first.is_closed() && second.is_closed());
        assert_eq!(report.cleanup.as_ref().unwrap().records.iter().map(|r| r.name).collect::<Vec<_>>(), ["dependent", "second", "first"]);
    }

    #[tokio::test]
    async fn async_connect_auth_failure_retains_native_cause_and_registered_close() {
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            scope.reserve_cleanup("prior").unwrap().register(|| async { Ok(()) });
            connect_in(scope.reserve_cleanup("pool").unwrap(), options(), connection().username("missing_role_for_pool_experiment"), &context()).await.map(|_| ())
        })).start().wait().await.unwrap();
        assert!(matches!(&report.work, Err(CommandCause::Failed(batter::operation::OperationError::Failed(failure))) if matches!(failure.native(), sqlx::Error::Database(db) if db.code().as_deref() == Some("28000"))));
        let cleanup = report.cleanup.as_ref().unwrap();
        assert!(cleanup.is_success());
        assert_eq!(cleanup.records.iter().map(|r| r.name).collect::<Vec<_>>(), ["pool", "prior"]);
    }

    #[tokio::test]
    async fn sync_creation_does_not_mistake_lazy_success_for_authentication() {
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let pool = pool_in(scope.reserve_cleanup("pool").unwrap(), options(), connection().username("missing_role_for_pool_experiment"));
            assert!(!pool.is_closed());
            batter_sqlx::probe(&pool, &context()).await
        })).start().wait().await.unwrap();
        assert!(matches!(&report.work, Err(CommandCause::Failed(batter::operation::OperationError::Failed(failure))) if matches!(failure.native(), sqlx::Error::Database(db) if db.code().as_deref() == Some("28000"))));
        assert!(report.cleanup.as_ref().unwrap().is_success());
    }

    #[tokio::test]
    async fn async_connect_success_then_fallible_work_preserves_both_outcomes() {
        let observed = Arc::new(Mutex::new(None));
        let published = observed.clone();
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let pool = connect_in(scope.reserve_cleanup("pool").unwrap(), options(), connection(), &context()).await.unwrap();
            *published.lock().unwrap() = Some(pool.clone());
            let answer: i32 = sqlx::query_scalar("SELECT 42::int4").fetch_one(&pool).await.unwrap();
            assert_eq!(answer, 42);
            Err::<(), _>(std::io::Error::other("private-work-marker"))
        })).start().wait().await.unwrap();
        assert!(matches!(&report.work, Err(CommandCause::Failed(error)) if error.to_string() == "private-work-marker"));
        assert!(report.cleanup.as_ref().unwrap().is_success());
        assert!(observed.lock().unwrap().as_ref().unwrap().is_closed());
        assert!(!format!("{report:?}").contains("private-work-marker"));
    }

    #[tokio::test]
    async fn async_connect_cancelled_in_auth_handshake_keeps_cleanup() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let command = Command::new(context(), budget(), move |scope| Box::pin(async move {
            connect_in(scope.reserve_cleanup("pool").unwrap(), options().acquire_timeout(Duration::from_secs(20)), connection().host("127.0.0.1").port(port), &context()).await.map(|_| ())
        })).start();
        let (_socket, _) = tokio::time::timeout(Duration::from_secs(2), listener.accept()).await.unwrap().unwrap();
        let observer = command.observer();
        drop(command);
        let report = observer.wait().await.unwrap();
        assert!(matches!(&report.work, Err(CommandCause::Interrupted(_))));
        let cleanup = report.cleanup.as_ref().unwrap();
        assert!(cleanup.is_success());
        assert_eq!(cleanup.records[0].name, "pool");
    }

    #[tokio::test]
    async fn async_connect_never_polled_and_pre_cancelled_create_no_pool_hook() {
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let ctx = context();
            let never_polled = connect_in(scope.reserve_cleanup("pool").unwrap(), options(), connection(), &ctx);
            drop(never_polled);
            ctx.cancel();
            assert!(connect_in(scope.reserve_cleanup("pool").unwrap(), options(), connection(), &ctx).await.is_err());
            Ok::<_, RegistrationError>(())
        })).start().wait().await.unwrap();
        assert!(report.is_success());
        assert!(report.cleanup.as_ref().unwrap().records.is_empty());
    }

    #[tokio::test]
    async fn retained_native_connection_reports_close_timeout_without_clean_claim() {
        let held = Arc::new(Mutex::new(None));
        let held_for_work = held.clone();
        let observed = Arc::new(Mutex::new(None));
        let published = observed.clone();
        let short_cleanup = CleanupBudget::new(Duration::from_millis(100), Duration::from_millis(50), Duration::from_secs(1)).unwrap();
        let report = Command::new(context(), short_cleanup, move |scope| Box::pin(async move {
            let pool = pool_in(scope.reserve_cleanup("pool")?, options(), connection());
            *held_for_work.lock().unwrap() = Some(pool.acquire().await.unwrap());
            *published.lock().unwrap() = Some(pool);
            Ok::<_, RegistrationError>(())
        })).start().wait().await.unwrap();
        assert!(!report.is_success());
        assert_eq!(report.cleanup.as_ref().unwrap().records[0].outcome, CleanupOutcome::TimedOut);
        let pool = observed.lock().unwrap().clone().unwrap();
        assert!(pool.is_closed());
        drop(held.lock().unwrap().take());
        tokio::time::timeout(Duration::from_secs(2), pool.close()).await.unwrap();
    }

    #[tokio::test]
    async fn native_callbacks_and_options_survive_protected_construction() {
        let connects = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let counted = connects.clone();
        let report = Command::new(context(), budget(), move |scope| Box::pin(async move {
            let opts = options().max_connections(3).min_connections(1)
                .after_connect(move |_, _| {
                    counted.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                    Box::pin(async { Ok(()) })
                });
            let pool = pool_in(scope.reserve_cleanup("pool")?, opts, connection().application_name("pool-api-experiment"));
            assert_eq!(pool.options().get_max_connections(), 3);
            assert_eq!(pool.options().get_min_connections(), 1);
            let name: String = sqlx::query_scalar("SHOW application_name").fetch_one(&pool).await.unwrap();
            assert_eq!(name, "pool-api-experiment");
            Ok::<_, RegistrationError>(())
        })).start().wait().await.unwrap();
        assert!(report.is_success());
        assert!(connects.load(std::sync::atomic::Ordering::SeqCst) >= 1);
    }
}
