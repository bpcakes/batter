# Experimental public API comparison

This is a scratch API experiment, not an installed Batter API.

Candidate A:

```rust
pub fn pool_in(
    slot: batter::cleanup::CleanupSlot<'_>,
    options: sqlx::postgres::PgPoolOptions,
    connection: sqlx::postgres::PgConnectOptions,
) -> sqlx::PgPool;
```

Use inside an owned `Command` or `Startup` callback. Reserve a named cleanup
slot, then pass it with native SQLx options. Creation and cleanup registration
complete synchronously before the pool is returned. The library owner awaits
pool close in LIFO order after the callback finishes, fails, or is cancelled.
Cleanup is bounded by the owner's budget and may be reported incomplete.
The returned pool is native and cloneable; retaining a clone does not prevent
close. Retaining a checked-out connection can delay close.

This is SQLx lazy construction: it does not authenticate or check readiness.
SQLx may start maintenance work during lazy construction, according to native
pool options. Perform an explicit bounded probe or application query when
connectivity is required before dependent initialization. Native options retain
their configured callbacks, timeouts, and environment-reading behavior.
The adapter does not read configuration, choose retries, provision databases,
approve readiness, or establish that remote server sessions have terminated.

Candidate C:

```rust
pub async fn connect_in(
    slot: batter::cleanup::CleanupSlot<'_>,
    options: sqlx::postgres::PgPoolOptions,
    connection: sqlx::postgres::PgConnectOptions,
    context: &batter::operation::OperationContext,
) -> Result<sqlx::PgPool,
    batter::operation::OperationError<batter_sqlx::SqlxFailure>>;
```

Use inside the same owned callbacks. The helper constructs a lazy pool,
registers its close before awaiting, then acquires and returns one native
connection under the supplied deadline/cancellation. Its successful return
means one connection was acquired. It does not execute a readiness query,
guarantee full min_connections warmup, or claim exact equivalence to native
`PgPoolOptions::connect_with`. Native connection return callbacks still apply.
Returned failure preserves the native SQLx error; acquisition interruption is
separate. A never-polled helper or already-interrupted context creates no pool
and registers no hook. A failed/interrupted acquisition after construction
leaves the pool-close hook with the owner, including before the pool was returned.

Existing owner APIs relevant to using either candidate:

```rust
Command::new(context, cleanup_budget, move |scope| Box::pin(async move {
    let slot = scope.reserve_cleanup("database")?;
    // Candidate call, followed by native application work.
    Ok::<_, ApplicationError>(())
})).start();
```

`StartupScope` currently reaches the same reservation via
`scope.supervisor().reserve_cleanup(name)`; its proposed constrained direct
reservation API is a separate experiment.

Assess each candidate on the same behavioral request: construct an owned finite
database command, require authentication before dependent work, execute a query,
then introduce fallible work after obtaining the pool. Preserve typed work
failure and cleanup evidence. No helper manually coordinating close should be
necessary. Use only this public contract and existing owner documentation.
