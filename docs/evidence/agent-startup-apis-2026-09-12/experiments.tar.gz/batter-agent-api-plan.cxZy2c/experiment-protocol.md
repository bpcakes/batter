# Agent startup API experiments

Recorded before consumer delegation, 2026-09-12.
Repository baseline: 809d5d5b913d26497232f13682b334e1c4aec806.
Existing concurrent documentation/tracker work belongs to batter-fbd.

## Question and scope

Which small native Rust/Tokio interfaces remove the three confirmed consumer
protocols: Unix signal handling across startup, PostgreSQL pool cleanup
registration around initialization, and excessive startup registration authority?
This is API-design evidence, not a population benchmark or production acceptance.

## Comparison rules

Prototype implementers inspect production sources and make at least two candidate
designs per issue explicit. A runnable prototype may test a preferred candidate;
an unimplemented alternative remains an architectural comparison only.
Use the real current Rust types and native dependencies wherever feasible.
Record compile failures, test failures, corrections and exact commands.
An imitation interface cannot establish the behavior of a future production API.

Fresh consumer agents receive a small application requirement and public API
documentation, not prototype internals or held-out oracle source. They may inspect
existing public Batter guidance and compiler diagnostics. Their initial artifact
must be retained before fixes, and any repairs must be counted and explained.
Do not prescribe function signatures that choose the lifecycle ownership types.
The host fixture may require a binary invocation/observable text protocol; this
does not prescribe the implementation's internal function or ownership signatures.
Repeated use of one agent is a modification exercise, not an independent sample.

## Consumer assignments

S: Build a Unix service that acquires an explicitly finalized resource, performs
a blocking initialization stage, then starts a critical component. SIGTERM and
SIGINT must request bounded owned cleanup during initialization and after startup.
Borrowed waiter cancellation must not cancel startup. Preserve returned failure
and cleanup outcomes, and report only sanitized counts/categories by default.
Modify it to add another fallible startup stage without rebuilding signal routing.

P: Build a finite setup command and a service startup path that create a native
PostgreSQL pool using supplied native options. All acquired pools must have an
awaited close owner before subsequent fallible initialization. Use the pool for
an actual SELECT 1. Duplicate cleanup registration must fail before creating the
rejected pool. Modify it to acquire a second pool and retain both original work
failure and cleanup outcome when initialization then fails.

R: Build a reusable registration function used in owned startup that adds a
critical component and resource finalizer, and composes an optional native adapter.
The helper must not obtain ownership of the enclosing process or its cleanup stack.
Modify it to add a second component without starting another driver. Independently
compile misuse attempts to extract cleanup, replace/start the supervisor, or let
the borrowed registration authority outlive the startup callback.

## Independent behavioral oracles

Signals: send real OS signals from a parent subprocess after an acknowledged
resource-acquired marker while initialization is held. Require one cleanup marker,
no service readiness, a retained startup interruption outcome, and bounded child
exit. Send during acknowledged running state and require owned normal drain.
A deliberately omitted startup signal owner must fail the initialization case.
Do not infer a handoff race was exercised solely because a timer happened nearby.

Pool: independently retain native pool clones; verify closed state after awaited
command/startup failure, positive native query success, duplicate-name rejection
before native side effects, and close waiting for a held checkout when exercised.
Do not infer server-session death from pool closure. Catalog/session observations
require an independent connection and are outside the requested minimum.

Registration: positive compilation must include the same adapter surface as the
negative subjects. Negative compiler tests must assert the intended inaccessible
operation, not merely any nonzero compilation result. No unsafe/DerefMut/AsMut or
public route back to &mut Supervisor is permitted on the canonical capability.
Types cannot prevent arbitrary external tokio::spawn calls or application-owned
handles captured before startup; make this limitation explicit.

## Evidence denominator and limits

Report number of fresh consumer agents, candidate interfaces actually executed,
initial implementation attempts, repairs, and modification attempts separately.
Success means a bounded example satisfied the selected behavioral oracles.
Compiler errors and accepted-but-incorrect consumer code are counterevidence.
No throughput, latency, cost, broad convergence or reliability percentage claim.
Linux execution does not establish macOS or hosted execution.

## Decision rule

Prefer a candidate that removes a lifecycle obligation with native ownership,
supports the real existing adapters, and exposes fewer semantically invalid
operations. Consider diagnostics, source migration and discoverability alongside
successful behavior. An API that merely relocates the same manual protocol into
each application does not close the finding. Keep intentional native/application
policy choices visible. Record unresolved hypotheses as implementation acceptance,
not executed results.
