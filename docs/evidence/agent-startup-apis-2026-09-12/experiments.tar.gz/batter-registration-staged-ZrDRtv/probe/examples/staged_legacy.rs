fn existing(scope: &mut batter::startup::StartupScope) {
    let _ = scope.supervisor().take_cleanup();
}
fn main() { let _ = existing; }
