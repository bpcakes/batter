# Fresh protected-registration consumer experiment

Scope: public consumer behavior only; no full-production guarantee. Work directory: /home/aa/.cache/batter-fresh-registration-80waV4.

## Choice and inputs

Chose `Startup::scoped` with a reusable HTTP helper taking `&mut batter::registration::Registration<'_>`, delegating to `registration_probe::concrete_http`. The second helper takes that same concrete borrowed view. This explicitly describes helper authority without a generic type parameter. Neither helper owns the enclosing process, extracts cleanup, starts a driver, or spawns service descendants. One `Startup::scoped(...).start()` owns both components after modification. I did not compile a generic-helper alternative, so this is a consumer preference, not comparative usability evidence.

Read only the supplied PUBLIC_API.md, public repository README/docs/usage, and public rustdoc HTML for Startup, Supervisor, ShutdownBudget, ProcessHandle, CleanupSlot and ShutdownReport. Generated public prototype rustdoc to discover the registration module after an import error. Did not inspect prototype implementation, tests, planning files, prior reports, or tracker.

## Original task

The initializer reserves cleanup, acquires an owned semaphore permit, immediately registers its finalizer, binds a native loopback listener and delegates HTTP registration to an application helper. The router retains an Arc lifetime witness; finalization checks that no router owner remains before releasing the permit and recording explicit finalization. The caller waits for readiness, verifies the permit is held, sends a real HTTP/1.1 request over TcpStream, requests shutdown and inspects complete report success and direct joins. It then checks permit restoration and witness-before-finalizer event order.

Preserved first authored source: `original/initial-main.rs`.
Repaired successful source: `original/src/main.rs`.
First compilation log: `original/attempt-1.log`.
Successful second compile/run log: `original/attempt-2.log`.

First compile failed with:
1. E0432: guessed `batter::lifecycle::Registration`; actual public path is `batter::registration::Registration`. The supplied API brief omitted the import path.
2. E0277: initializer error `BoxError` could not make `StartupError<BoxError>` convertible through `?` to the application BoxError. Repaired with a concrete `InitError(BoxError)` implementing Error and wrapping the initializer result. The brief calls for concrete errors, but the available example did not show mixed registration/acquisition/I/O errors; this was a consumer mistake.
3. E0599: assumed `check_shutdown` returned the report, but it returns unit. Repaired by inspecting the raw successful report first and then passing it to `check_shutdown`. This was a consumer mistake from reading usage without the function return signature.

Second compilation and runtime passed. No runtime failures or behavior repairs occurred.

## Modification task

Added `register_maintenance(&mut Registration, Arc<Semaphore>, Events)`: it reserves cleanup, acquires a second permit, registers the second finalizer, and registers a direct critical component. That component acknowledges initialization, awaits drain, records completion, and returns. Its finalizer checks completion before releasing the resource. The root retains the single startup owner and driver.

Preserved initial modified source: `modified/initial-main.rs`.
Successful source (identical): `modified/src/main.rs`.
First compile/run log: `modified/attempt-1.log`.
The modification compiled and ran on its first attempt, without repairs.

Observed events:
`maintenance-completed, http-state-released, maintenance-resource-released, http-resource-released`.

Assertions permit either ordering of component completion events, require both before cleanup, require LIFO finalizer order, require both restored permits, and require complete successful shutdown. No arbitrary service descendants or global tracing subscriber are introduced. Router-state destruction is a lifetime observation; complete successful adapter shutdown supplies the separate supervision outcome. This does not independently prove arbitrary remote effects or production shutdown behavior.

## Rerunnable commands

From /home/aa/Documents/batter (any cwd is also valid with these absolute manifest paths):

```sh
RUSTUP_TOOLCHAIN=1.98.1 CARGO_TARGET_DIR=/home/aa/Documents/batter/target TMPDIR=/home/aa/.cache cargo run --locked --manifest-path /home/aa/.cache/batter-fresh-registration-80waV4/original/Cargo.toml
RUSTUP_TOOLCHAIN=1.98.1 CARGO_TARGET_DIR=/home/aa/Documents/batter/target TMPDIR=/home/aa/.cache cargo run --locked --manifest-path /home/aa/.cache/batter-fresh-registration-80waV4/modified/Cargo.toml
```

Both package manifests have independent [workspace] declarations and Cargo-generated lockfiles. Dependencies pin Axum 0.8.9 and Tokio 1.53.1; prototype paths remain /tmp/batter-registration-staged-ZrDRtv/core and /tmp/batter-registration-staged-ZrDRtv/probe. Those prototype directories must remain available to rerun. The public-doc build command and output are retained in original/public-doc-build.log.

