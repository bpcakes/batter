use batter::{RegistrationError, registration::{Registration, RegistrationTarget}};
use axum::Router;
use tokio::net::TcpListener;

pub fn concrete_http(target: &mut Registration<'_>, name: &'static str, listener: TcpListener, application: Router) -> Result<(), RegistrationError> {
    target.register(name, move |shutdown| async move {
        shutdown.mark_started();
        axum::serve(listener, application)
            .with_graceful_shutdown(async move { shutdown.draining().await }).await?;
        Ok(())
    })
}

pub fn generic_http(target: &mut impl RegistrationTarget, name: &'static str, listener: TcpListener, application: Router) -> Result<(), RegistrationError> {
    concrete_http(&mut target.registration(), name, listener, application)
}

#[cfg(test)]
mod tests {
    use super::*;
    use batter::{BoxError, cleanup::CleanupBudget, lifecycle::{ShutdownBudget, Supervisor}, operation::OperationContext, startup::Startup};
    use std::{sync::{Arc, Mutex}, time::Duration};
    fn budgets() -> (Supervisor, CleanupBudget) {
        let sec = Duration::from_secs(1);
        let cleanup = CleanupBudget::new(sec,sec,sec).unwrap();
        (Supervisor::new(ShutdownBudget::new(sec,sec,sec,cleanup).unwrap()),cleanup)
    }
    #[tokio::test]
    async fn concrete_scope_native_http_and_lifo() -> Result<(), BoxError> {
        let (process, cleanup) = budgets();
        let observed = Arc::new(Mutex::new(Vec::new()));
        let collected = observed.clone();
        let mut startup = Startup::scoped(process, OperationContext::new(Duration::from_secs(3))?, cleanup, move |scope| Box::pin(async move {
            for index in 0..2 {
                let slot = scope.reserve_cleanup(if index == 0 { "first" } else { "second" })?;
                let collected = collected.clone();
                slot.register(move || async move { collected.lock().unwrap().push(index); Ok(()) });
            }
            let listener = TcpListener::bind("127.0.0.1:0").await?;
            concrete_http(&mut scope.registration(), "http", listener, Router::new())?;
            Ok::<_, BoxError>(())
        })).start();
        let running = startup.wait().await.expect("startup succeeds");
        running.handle().wait_ready().await.unwrap();
        assert!(running.shutdown().await?.is_success());
        assert_eq!(*observed.lock().unwrap(), vec![1,0]);
        Ok(())
    }
    #[tokio::test]
    async fn generic_target_supports_scope_and_supervisor() -> Result<(), BoxError> {
        let (mut process, cleanup) = budgets();
        generic_http(&mut process, "first", TcpListener::bind("127.0.0.1:0").await?, Router::new())?;
        let mut startup = Startup::scoped(process, OperationContext::new(Duration::from_secs(3))?, cleanup, move |scope| Box::pin(async move {
            generic_http(scope, "second", TcpListener::bind("127.0.0.1:0").await?, Router::new())?;
            Ok::<_, BoxError>(())
        })).start();
        let running = startup.wait().await.expect("startup succeeds");
        running.handle().wait_ready().await.unwrap();
        assert!(running.shutdown().await?.is_success());
        Ok(())
    }
}
