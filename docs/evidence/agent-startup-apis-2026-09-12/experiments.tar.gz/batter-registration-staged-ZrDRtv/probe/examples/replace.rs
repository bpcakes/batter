fn misuse(scope: &mut batter::startup::ProtectedStartupScope, replacement: batter::lifecycle::Supervisor) {
    let _ = std::mem::replace(&mut scope.registration(), replacement);
}
fn main() {}
