fn misuse(scope: &mut batter::startup::ProtectedStartupScope) {
    let _ = scope.supervisor();
}
fn main() {}
